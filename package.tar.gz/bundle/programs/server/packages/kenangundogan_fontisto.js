(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

var require = meteorInstall({"node_modules":{"meteor":{"kenangundogan:fontisto":{"fontisto.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/kenangundogan_fontisto/fontisto.js                       //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var module1 = module;                                                // 1
module1.export({                                                     // 1
  name: function () {                                                // 1
    return name;                                                     // 1
  }                                                                  // 1
});                                                                  // 1
var name = 'fontisto';                                               // 5
///////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/kenangundogan:fontisto/fontisto.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kenangundogan:fontisto'] = exports;

})();

//# sourceMappingURL=kenangundogan_fontisto.js.map

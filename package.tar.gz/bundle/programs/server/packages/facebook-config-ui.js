(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['facebook-config-ui'] = {};

})();

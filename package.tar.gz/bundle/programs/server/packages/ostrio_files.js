(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var meteorInstall = Package.modules.meteorInstall;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

/* Package-scope variables */
var __coffeescriptShare, FilesCollection;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:files":{"server.coffee.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/server.coffee.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
module.export({FilesCollection:function(){return FilesCollection}});var Cookies;module.import('meteor/ostrio:cookies',{"Cookies":function(v){Cookies=v}});var writeStream;module.import('./write-stream.coffee',{"writeStream":function(v){writeStream=v}});var FilesCollectionCore;module.import('./core.coffee',{"FilesCollectionCore":function(v){FilesCollectionCore=v}});var fixJSONParse,fixJSONStringify,formatFleURL;module.import('./lib.coffee',{"fixJSONParse":function(v){fixJSONParse=v},"fixJSONStringify":function(v){fixJSONStringify=v},"formatFleURL":function(v){formatFleURL=v}});var fs;module.import('fs-extra',{"default":function(v){fs=v}});var nodeQs;module.import('querystring',{"default":function(v){nodeQs=v}});var events;module.import('events',{"default":function(v){events=v}});var request;module.import('request',{"default":function(v){request=v}});var Throttle;module.import('throttle',{"default":function(v){Throttle=v}});var fileType;module.import('file-type',{"default":function(v){fileType=v}});var nodePath;module.import('path',{"default":function(v){nodePath=v}});
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
/*                                                                                                                     //
@summary Require NPM packages                                                                                          //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
                                                                                                                       //
/*                                                                                                                     //
@var {Object} bound - Meteor.bindEnvironment (Fiber wrapper)                                                           //
 */                                                                                                                    //
var NOOP, bound;                                                                                                       //
                                                                                                                       //
bound = Meteor.bindEnvironment(function (callback) {                                                                   //
  return callback();                                                                                                   //
});                                                                                                                    //
                                                                                                                       //
NOOP = function NOOP() {};                                                                                             //
                                                                                                                       //
/*                                                                                                                     //
@locus Anywhere                                                                                                        //
@class FilesCollection                                                                                                 //
@param config           {Object}   - [Both]   Configuration object with next properties:                               //
@param config.debug     {Boolean}  - [Both]   Turn on/of debugging and extra logging                                   //
@param config.schema    {Object}   - [Both]   Collection Schema                                                        //
@param config.public    {Boolean}  - [Both]   Store files in folder accessible for proxy servers, for limits, and more - read docs
@param config.strict    {Boolean}  - [Server] Strict mode for partial content, if is `true` server will return `416` response code, when `range` is not specified, otherwise server return `206`
@param config.protected {Function} - [Both]   If `true` - files will be served only to authorized users, if `function()` - you're able to check visitor's permissions in your own way function's context has:
  - `request` - On server only                                                                                         //
  - `response` - On server only                                                                                        //
  - `user()`                                                                                                           //
  - `userId`                                                                                                           //
@param config.chunkSize      {Number}  - [Both] Upload chunk size, default: 524288 bytes (0,5 Mb)                      //
@param config.permissions    {Number}  - [Server] Permissions which will be set to uploaded files (octal), like: `511` or `0o755`. Default: 0644
@param config.parentDirPermissions {Number}  - [Server] Permissions which will be set to parent directory of uploaded files (octal), like: `611` or `0o777`. Default: 0755
@param config.storagePath    {String|Function}  - [Server] Storage path on file system                                 //
@param config.cacheControl   {String}  - [Server] Default `Cache-Control` header                                       //
@param config.responseHeaders {Object|Function} - [Server] Custom response headers, if function is passed, must return Object
@param config.throttle       {Number}  - [Server] bps throttle threshold                                               //
@param config.downloadRoute  {String}  - [Both]   Server Route used to retrieve files                                  //
@param config.collection     {Mongo.Collection} - [Both] Mongo Collection Instance                                     //
@param config.collectionName {String}  - [Both]   Collection name                                                      //
@param config.namingFunction {Function}- [Both]   Function which returns `String`                                      //
@param config.integrityCheck {Boolean} - [Server] Check file's integrity before serving to users                       //
@param config.onAfterUpload  {Function}- [Server] Called right after file is ready on FS. Use to transfer file somewhere else, or do other thing with file directly
@param config.onAfterRemove  {Function} - [Server] Called right after file is removed. Removed objects is passed to callback
@param config.continueUploadTTL {Number} - [Server] Time in seconds, during upload may be continued, default 3 hours (10800 seconds)
@param config.onBeforeUpload {Function}- [Both]   Function which executes on server after receiving each chunk and on client right before beginning upload. Function context is `File` - so you are able to check for extension, mime-type, size and etc.
return `true` to continue                                                                                              //
return `false` or `String` to abort upload                                                                             //
@param config.onInitiateUpload {Function} - [Server] Function which executes on server right before upload is begin and right after `onBeforeUpload` hook. This hook is fully asynchronous.
@param config.onBeforeRemove {Function} - [Server] Executes before removing file on server, so you can check permissions. Return `true` to allow action and `false` to deny.
@param config.allowClientCode  {Boolean}  - [Both]   Allow to run `remove` from client                                 //
@param config.downloadCallback {Function} - [Server] Callback triggered each time file is requested, return truthy value to continue download, or falsy to abort
@param config.interceptDownload {Function} - [Server] Intercept download request, so you can serve file from third-party resource, arguments {http: {request: {...}, response: {...}}, fileRef: {...}}
@summary Create new instance of FilesCollection                                                                        //
 */                                                                                                                    //
                                                                                                                       //
module.runModuleSetters(FilesCollection = function () {                                                                //
  FilesCollection.prototype.__proto__ = function () {                                                                  //
    return _.extend(events.EventEmitter.prototype, FilesCollectionCore.prototype);                                     //
  }();                                                                                                                 //
                                                                                                                       //
  function FilesCollection(config) {                                                                                   //
    var _iwcz, _methods, _preCollectionCursor, cookie, self, storagePath;                                              //
    events.EventEmitter.call(this);                                                                                    //
    if (config) {                                                                                                      //
      storagePath = config.storagePath, this.ddp = config.ddp, this.collection = config.collection, this.collectionName = config.collectionName, this.downloadRoute = config.downloadRoute, this.schema = config.schema, this.chunkSize = config.chunkSize, this.namingFunction = config.namingFunction, this.debug = config.debug, this.onbeforeunloadMessage = config.onbeforeunloadMessage, this.permissions = config.permissions, this.parentDirPermissions = config.parentDirPermissions, this.allowClientCode = config.allowClientCode, this.onBeforeUpload = config.onBeforeUpload, this.onInitiateUpload = config.onInitiateUpload, this.integrityCheck = config.integrityCheck, this["protected"] = config["protected"], this["public"] = config["public"], this.strict = config.strict, this.downloadCallback = config.downloadCallback, this.cacheControl = config.cacheControl, this.responseHeaders = config.responseHeaders, this.throttle = config.throttle, this.onAfterUpload = config.onAfterUpload, this.onAfterRemove = config.onAfterRemove, this.interceptDownload = config.interceptDownload, this.onBeforeRemove = config.onBeforeRemove, this.continueUploadTTL = config.continueUploadTTL;
    }                                                                                                                  //
    self = this;                                                                                                       //
    cookie = new Cookies();                                                                                            //
    if (this.debug == null) {                                                                                          //
      this.debug = false;                                                                                              //
    }                                                                                                                  //
    this._debug = function () {                                                                                        //
      if (self.debug) {                                                                                                //
        return console.info.apply(void 0, arguments);                                                                  //
      }                                                                                                                //
    };                                                                                                                 //
    if (this["public"] == null) {                                                                                      //
      this["public"] = false;                                                                                          //
    }                                                                                                                  //
    if (this["protected"] == null) {                                                                                   //
      this["protected"] = false;                                                                                       //
    }                                                                                                                  //
    if (this.chunkSize == null) {                                                                                      //
      this.chunkSize = 1024 * 512;                                                                                     //
    }                                                                                                                  //
    this.chunkSize = Math.floor(this.chunkSize / 8) * 8;                                                               //
    if (this["public"] && !this.downloadRoute) {                                                                       //
      throw new Meteor.Error(500, "[FilesCollection." + this.collectionName + "]: \"downloadRoute\" must be precisely provided on \"public\" collections! Note: \"downloadRoute\" must be equal or be inside of your web/proxy-server (relative) root.");
    }                                                                                                                  //
    if (this.collection == null) {                                                                                     //
      this.collection = new Mongo.Collection(this.collectionName);                                                     //
    }                                                                                                                  //
    this.collection.filesCollection = this;                                                                            //
    if (this.collectionName == null) {                                                                                 //
      this.collectionName = this.collection._name;                                                                     //
    }                                                                                                                  //
    check(this.collectionName, String);                                                                                //
    if (this.downloadRoute == null) {                                                                                  //
      this.downloadRoute = '/cdn/storage';                                                                             //
    }                                                                                                                  //
    this.downloadRoute = this.downloadRoute.replace(/\/$/, '');                                                        //
    if (this.collectionName == null) {                                                                                 //
      this.collectionName = 'MeteorUploadFiles';                                                                       //
    }                                                                                                                  //
    if (this.namingFunction == null) {                                                                                 //
      this.namingFunction = false;                                                                                     //
    }                                                                                                                  //
    if (this.onBeforeUpload == null) {                                                                                 //
      this.onBeforeUpload = false;                                                                                     //
    }                                                                                                                  //
    if (this.allowClientCode == null) {                                                                                //
      this.allowClientCode = true;                                                                                     //
    }                                                                                                                  //
    if (this.ddp == null) {                                                                                            //
      this.ddp = Meteor;                                                                                               //
    }                                                                                                                  //
    if (this.onInitiateUpload == null) {                                                                               //
      this.onInitiateUpload = false;                                                                                   //
    }                                                                                                                  //
    if (this.interceptDownload == null) {                                                                              //
      this.interceptDownload = false;                                                                                  //
    }                                                                                                                  //
    if (storagePath == null) {                                                                                         //
      storagePath = function storagePath() {                                                                           //
        return "assets" + nodePath.sep + "app" + nodePath.sep + "uploads" + nodePath.sep + this.collectionName;        //
      };                                                                                                               //
    }                                                                                                                  //
    if (_.isString(storagePath)) {                                                                                     //
      this.storagePath = function () {                                                                                 //
        return storagePath;                                                                                            //
      };                                                                                                               //
    } else {                                                                                                           //
      this.storagePath = function () {                                                                                 //
        var sp;                                                                                                        //
        sp = storagePath.apply(this, arguments);                                                                       //
        if (!_.isString(sp)) {                                                                                         //
          throw new Meteor.Error(400, "[FilesCollection." + self.collectionName + "] \"storagePath\" function must return a String!");
        }                                                                                                              //
        sp = sp.replace(/\/$/, '');                                                                                    //
        return nodePath.normalize(sp);                                                                                 //
      };                                                                                                               //
    }                                                                                                                  //
    if (this.strict == null) {                                                                                         //
      this.strict = true;                                                                                              //
    }                                                                                                                  //
    if (this.throttle == null) {                                                                                       //
      this.throttle = false;                                                                                           //
    }                                                                                                                  //
    if (this.permissions == null) {                                                                                    //
      this.permissions = parseInt('644', 8);                                                                           //
    }                                                                                                                  //
    if (this.parentDirPermissions == null) {                                                                           //
      this.parentDirPermissions = parseInt('755', 8);                                                                  //
    }                                                                                                                  //
    if (this.cacheControl == null) {                                                                                   //
      this.cacheControl = 'public, max-age=31536000, s-maxage=31536000';                                               //
    }                                                                                                                  //
    if (this.onAfterUpload == null) {                                                                                  //
      this.onAfterUpload = false;                                                                                      //
    }                                                                                                                  //
    if (this.onAfterRemove == null) {                                                                                  //
      this.onAfterRemove = false;                                                                                      //
    }                                                                                                                  //
    if (this.onBeforeRemove == null) {                                                                                 //
      this.onBeforeRemove = false;                                                                                     //
    }                                                                                                                  //
    if (this.integrityCheck == null) {                                                                                 //
      this.integrityCheck = true;                                                                                      //
    }                                                                                                                  //
    if (this._currentUploads == null) {                                                                                //
      this._currentUploads = {};                                                                                       //
    }                                                                                                                  //
    if (this.downloadCallback == null) {                                                                               //
      this.downloadCallback = false;                                                                                   //
    }                                                                                                                  //
    if (this.continueUploadTTL == null) {                                                                              //
      this.continueUploadTTL = 10800;                                                                                  //
    }                                                                                                                  //
    if (this.responseHeaders == null) {                                                                                //
      this.responseHeaders = function (responseCode, fileRef, versionRef) {                                            //
        var headers;                                                                                                   //
        headers = {};                                                                                                  //
        switch (responseCode) {                                                                                        //
          case '206':                                                                                                  //
            headers['Pragma'] = 'private';                                                                             //
            headers['Trailer'] = 'expires';                                                                            //
            headers['Transfer-Encoding'] = 'chunked';                                                                  //
            break;                                                                                                     //
          case '400':                                                                                                  //
            headers['Cache-Control'] = 'no-cache';                                                                     //
            break;                                                                                                     //
          case '416':                                                                                                  //
            headers['Content-Range'] = "bytes */" + versionRef.size;                                                   //
        }                                                                                                              //
        headers['Connection'] = 'keep-alive';                                                                          //
        headers['Content-Type'] = versionRef.type || 'application/octet-stream';                                       //
        headers['Accept-Ranges'] = 'bytes';                                                                            //
        return headers;                                                                                                //
      };                                                                                                               //
    }                                                                                                                  //
    if (this["public"] && !storagePath) {                                                                              //
      throw new Meteor.Error(500, "[FilesCollection." + this.collectionName + "] \"storagePath\" must be set on \"public\" collections! Note: \"storagePath\" must be equal on be inside of your web/proxy-server (absolute) root.");
    }                                                                                                                  //
    this._debug('[FilesCollection.storagePath] Set to:', this.storagePath({}));                                        //
    fs.mkdirs(this.storagePath({}), {                                                                                  //
      mode: this.parentDirPermissions                                                                                  //
    }, function (error) {                                                                                              //
      if (error) {                                                                                                     //
        throw new Meteor.Error(401, "[FilesCollection." + self.collectionName + "] Path \"" + self.storagePath({}) + "\" is not writable!", error);
      }                                                                                                                //
    });                                                                                                                //
    check(this.strict, Boolean);                                                                                       //
    check(this.throttle, Match.OneOf(false, Number));                                                                  //
    check(this.permissions, Number);                                                                                   //
    check(this.storagePath, Function);                                                                                 //
    check(this.cacheControl, String);                                                                                  //
    check(this.onAfterRemove, Match.OneOf(false, Function));                                                           //
    check(this.onAfterUpload, Match.OneOf(false, Function));                                                           //
    check(this.integrityCheck, Boolean);                                                                               //
    check(this.onBeforeRemove, Match.OneOf(false, Function));                                                          //
    check(this.downloadCallback, Match.OneOf(false, Function));                                                        //
    check(this.interceptDownload, Match.OneOf(false, Function));                                                       //
    check(this.continueUploadTTL, Number);                                                                             //
    check(this.responseHeaders, Match.OneOf(Object, Function));                                                        //
    this._preCollection = new Mongo.Collection('__pre_' + this.collectionName);                                        //
    this._preCollection._ensureIndex({                                                                                 //
      createdAt: 1                                                                                                     //
    }, {                                                                                                               //
      expireAfterSeconds: this.continueUploadTTL,                                                                      //
      background: true                                                                                                 //
    });                                                                                                                //
    _preCollectionCursor = this._preCollection.find({}, {                                                              //
      fields: {                                                                                                        //
        _id: 1,                                                                                                        //
        isFinished: 1                                                                                                  //
      }                                                                                                                //
    });                                                                                                                //
    _preCollectionCursor.observe({                                                                                     //
      changed: function () {                                                                                           //
        function changed(doc) {                                                                                        //
          if (doc.isFinished) {                                                                                        //
            self._debug("[FilesCollection] [_preCollectionCursor.observe] [changed]: " + doc._id);                     //
            self._preCollection.remove({                                                                               //
              _id: doc._id                                                                                             //
            }, NOOP);                                                                                                  //
          }                                                                                                            //
        }                                                                                                              //
                                                                                                                       //
        return changed;                                                                                                //
      }(),                                                                                                             //
      removed: function () {                                                                                           //
        function removed(doc) {                                                                                        //
          var ref;                                                                                                     //
          self._debug("[FilesCollection] [_preCollectionCursor.observe] [removed]: " + doc._id);                       //
          if ((ref = self._currentUploads) != null ? ref[doc._id] : void 0) {                                          //
            self._currentUploads[doc._id].stop();                                                                      //
            self._currentUploads[doc._id].end();                                                                       //
            if (!doc.isFinished) {                                                                                     //
              self._debug("[FilesCollection] [_preCollectionCursor.observe] [removeUnfinishedUpload]: " + doc._id);    //
              self._currentUploads[doc._id].abort();                                                                   //
            }                                                                                                          //
            delete self._currentUploads[doc._id];                                                                      //
          }                                                                                                            //
        }                                                                                                              //
                                                                                                                       //
        return removed;                                                                                                //
      }()                                                                                                              //
    });                                                                                                                //
    this._createStream = function (_id, path, opts) {                                                                  //
      return self._currentUploads[_id] = new writeStream(path, opts.fileLength, opts, self.permissions);               //
    };                                                                                                                 //
    _iwcz = 0;                                                                                                         //
    this._continueUpload = function (_id) {                                                                            //
      var contUpld, ref, ref1;                                                                                         //
      if ((ref = self._currentUploads) != null ? (ref1 = ref[_id]) != null ? ref1.file : void 0 : void 0) {            //
        if (!self._currentUploads[_id].aborted && !self._currentUploads[_id].ended) {                                  //
          return self._currentUploads[_id].file;                                                                       //
        } else {                                                                                                       //
          self._createStream(_id, self._currentUploads[_id].file.file.path, self._currentUploads[_id].file);           //
          return self._currentUploads[_id].file;                                                                       //
        }                                                                                                              //
      } else {                                                                                                         //
        contUpld = self._preCollection.findOne({                                                                       //
          _id: _id                                                                                                     //
        });                                                                                                            //
        if (contUpld) {                                                                                                //
          self._createStream(_id, contUpld.file.path, contUpld);                                                       //
          return self._currentUploads[_id].file;                                                                       //
        }                                                                                                              //
        return false;                                                                                                  //
      }                                                                                                                //
    };                                                                                                                 //
    if (!this.schema) {                                                                                                //
      this.schema = {                                                                                                  //
        size: {                                                                                                        //
          type: Number                                                                                                 //
        },                                                                                                             //
        name: {                                                                                                        //
          type: String                                                                                                 //
        },                                                                                                             //
        type: {                                                                                                        //
          type: String                                                                                                 //
        },                                                                                                             //
        path: {                                                                                                        //
          type: String                                                                                                 //
        },                                                                                                             //
        isVideo: {                                                                                                     //
          type: Boolean                                                                                                //
        },                                                                                                             //
        isAudio: {                                                                                                     //
          type: Boolean                                                                                                //
        },                                                                                                             //
        isImage: {                                                                                                     //
          type: Boolean                                                                                                //
        },                                                                                                             //
        isText: {                                                                                                      //
          type: Boolean                                                                                                //
        },                                                                                                             //
        isJSON: {                                                                                                      //
          type: Boolean                                                                                                //
        },                                                                                                             //
        isPDF: {                                                                                                       //
          type: Boolean                                                                                                //
        },                                                                                                             //
        extension: {                                                                                                   //
          type: String,                                                                                                //
          optional: true                                                                                               //
        },                                                                                                             //
        _storagePath: {                                                                                                //
          type: String                                                                                                 //
        },                                                                                                             //
        _downloadRoute: {                                                                                              //
          type: String                                                                                                 //
        },                                                                                                             //
        _collectionName: {                                                                                             //
          type: String                                                                                                 //
        },                                                                                                             //
        "public": {                                                                                                    //
          type: Boolean,                                                                                               //
          optional: true                                                                                               //
        },                                                                                                             //
        meta: {                                                                                                        //
          type: Object,                                                                                                //
          blackbox: true,                                                                                              //
          optional: true                                                                                               //
        },                                                                                                             //
        userId: {                                                                                                      //
          type: String,                                                                                                //
          optional: true                                                                                               //
        },                                                                                                             //
        updatedAt: {                                                                                                   //
          type: Date,                                                                                                  //
          optional: true                                                                                               //
        },                                                                                                             //
        versions: {                                                                                                    //
          type: Object,                                                                                                //
          blackbox: true                                                                                               //
        }                                                                                                              //
      };                                                                                                               //
    }                                                                                                                  //
    check(this.debug, Boolean);                                                                                        //
    check(this.schema, Object);                                                                                        //
    check(this["public"], Boolean);                                                                                    //
    check(this["protected"], Match.OneOf(Boolean, Function));                                                          //
    check(this.chunkSize, Number);                                                                                     //
    check(this.downloadRoute, String);                                                                                 //
    check(this.namingFunction, Match.OneOf(false, Function));                                                          //
    check(this.onBeforeUpload, Match.OneOf(false, Function));                                                          //
    check(this.onInitiateUpload, Match.OneOf(false, Function));                                                        //
    check(this.allowClientCode, Boolean);                                                                              //
    check(this.ddp, Match.Any);                                                                                        //
    if (this["public"] && this["protected"]) {                                                                         //
      throw new Meteor.Error(500, "[FilesCollection." + this.collectionName + "]: Files can not be public and protected at the same time!");
    }                                                                                                                  //
    this._checkAccess = function (http) {                                                                              //
      var fileRef, rc, ref, ref1, result, text, user, userId;                                                          //
      if (self["protected"]) {                                                                                         //
        ref = self._getUser(http), user = ref.user, userId = ref.userId;                                               //
        if (_.isFunction(self["protected"])) {                                                                         //
          if (http != null ? (ref1 = http.params) != null ? ref1._id : void 0 : void 0) {                              //
            fileRef = self.collection.findOne(http.params._id);                                                        //
          }                                                                                                            //
          result = http ? self["protected"].call(_.extend(http, {                                                      //
            user: user,                                                                                                //
            userId: userId                                                                                             //
          }), fileRef || null) : self["protected"].call({                                                              //
            user: user,                                                                                                //
            userId: userId                                                                                             //
          }, fileRef || null);                                                                                         //
        } else {                                                                                                       //
          result = !!userId;                                                                                           //
        }                                                                                                              //
        if (http && result === true || !http) {                                                                        //
          return true;                                                                                                 //
        } else {                                                                                                       //
          rc = _.isNumber(result) ? result : 401;                                                                      //
          self._debug('[FilesCollection._checkAccess] WARN: Access denied!');                                          //
          if (http) {                                                                                                  //
            text = 'Access denied!';                                                                                   //
            if (!http.response.headersSent) {                                                                          //
              http.response.writeHead(rc, {                                                                            //
                'Content-Length': text.length,                                                                         //
                'Content-Type': 'text/plain'                                                                           //
              });                                                                                                      //
            }                                                                                                          //
            if (!http.response.finished) {                                                                             //
              http.response.end(text);                                                                                 //
            }                                                                                                          //
          }                                                                                                            //
          return false;                                                                                                //
        }                                                                                                              //
      } else {                                                                                                         //
        return true;                                                                                                   //
      }                                                                                                                //
    };                                                                                                                 //
    this._methodNames = {                                                                                              //
      _Abort: "_FilesCollectionAbort_" + this.collectionName,                                                          //
      _Write: "_FilesCollectionWrite_" + this.collectionName,                                                          //
      _Start: "_FilesCollectionStart_" + this.collectionName,                                                          //
      _Remove: "_FilesCollectionRemove_" + this.collectionName                                                         //
    };                                                                                                                 //
    this.on('_handleUpload', this._handleUpload);                                                                      //
    this.on('_finishUpload', this._finishUpload);                                                                      //
    WebApp.connectHandlers.use(function (request, response, next) {                                                    //
      var _file, body, handleError, http, params, uri, uris, version;                                                  //
      if (!!~request._parsedUrl.path.indexOf(self.downloadRoute + "/" + self.collectionName + "/__upload")) {          //
        if (request.method === 'POST') {                                                                               //
          handleError = function handleError(error) {                                                                  //
            console.warn("[FilesCollection] [Upload] [HTTP] Exception:", error);                                       //
            if (!response.headersSent) {                                                                               //
              response.writeHead(500);                                                                                 //
            }                                                                                                          //
            if (!response.finished) {                                                                                  //
              response.end(JSON.stringify({                                                                            //
                error: error                                                                                           //
              }));                                                                                                     //
            }                                                                                                          //
          };                                                                                                           //
          body = '';                                                                                                   //
          request.on('data', function (data) {                                                                         //
            return bound(function () {                                                                                 //
              body += data;                                                                                            //
            });                                                                                                        //
          });                                                                                                          //
          request.on('end', function () {                                                                              //
            return bound(function () {                                                                                 //
              var _continueUpload, e, error, opts, ref, ref1, ref2, ref3, result, user;                                //
              try {                                                                                                    //
                if (request.headers['x-mtok'] && ((ref = Meteor.server.sessions) != null ? ref[request.headers['x-mtok']] : void 0)) {
                  user = {                                                                                             //
                    userId: (ref1 = Meteor.server.sessions[request.headers['x-mtok']]) != null ? ref1.userId : void 0  //
                  };                                                                                                   //
                } else {                                                                                               //
                  user = self._getUser({                                                                               //
                    request: request,                                                                                  //
                    response: response                                                                                 //
                  });                                                                                                  //
                }                                                                                                      //
                if (request.headers['x-start'] !== '1') {                                                              //
                  opts = {                                                                                             //
                    fileId: request.headers['x-fileid']                                                                //
                  };                                                                                                   //
                  if (request.headers['x-eof'] === '1') {                                                              //
                    opts.eof = true;                                                                                   //
                  } else {                                                                                             //
                    if (typeof Buffer.from === 'function') {                                                           //
                      try {                                                                                            //
                        opts.binData = Buffer.from(body, 'base64');                                                    //
                      } catch (error1) {                                                                               //
                        e = error1;                                                                                    //
                        opts.binData = new Buffer(body, 'base64');                                                     //
                      }                                                                                                //
                    } else {                                                                                           //
                      opts.binData = new Buffer(body, 'base64');                                                       //
                    }                                                                                                  //
                    opts.chunkId = parseInt(request.headers['x-chunkid']);                                             //
                  }                                                                                                    //
                  _continueUpload = self._continueUpload(opts.fileId);                                                 //
                  if (!_continueUpload) {                                                                              //
                    throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');       //
                  }                                                                                                    //
                  ref2 = self._prepareUpload(_.extend(opts, _continueUpload), user.userId, 'HTTP'), result = ref2.result, opts = ref2.opts;
                  if (opts.eof) {                                                                                      //
                    self._handleUpload(result, opts, function () {                                                     //
                      var ref3;                                                                                        //
                      if (!response.headersSent) {                                                                     //
                        response.writeHead(200);                                                                       //
                      }                                                                                                //
                      if (result != null ? (ref3 = result.file) != null ? ref3.meta : void 0 : void 0) {               //
                        result.file.meta = fixJSONStringify(result.file.meta);                                         //
                      }                                                                                                //
                      if (!response.finished) {                                                                        //
                        response.end(JSON.stringify(result));                                                          //
                      }                                                                                                //
                    });                                                                                                //
                    return;                                                                                            //
                  } else {                                                                                             //
                    self.emit('_handleUpload', result, opts, NOOP);                                                    //
                  }                                                                                                    //
                  if (!response.headersSent) {                                                                         //
                    response.writeHead(204);                                                                           //
                  }                                                                                                    //
                  if (!response.finished) {                                                                            //
                    response.end();                                                                                    //
                  }                                                                                                    //
                } else {                                                                                               //
                  try {                                                                                                //
                    opts = JSON.parse(body);                                                                           //
                  } catch (error1) {                                                                                   //
                    e = error1;                                                                                        //
                    console.error('Can\'t parse incoming JSON from Client on [.insert() | upload], something went wrong!');
                    console.error(e);                                                                                  //
                    opts = {                                                                                           //
                      file: {}                                                                                         //
                    };                                                                                                 //
                  }                                                                                                    //
                  opts.___s = true;                                                                                    //
                  self._debug("[FilesCollection] [File Start HTTP] " + opts.file.name + " - " + opts.fileId);          //
                  if (opts != null ? (ref3 = opts.file) != null ? ref3.meta : void 0 : void 0) {                       //
                    opts.file.meta = fixJSONParse(opts.file.meta);                                                     //
                  }                                                                                                    //
                  result = self._prepareUpload(_.clone(opts), user.userId, 'HTTP Start Method').result;                //
                  if (self.collection.findOne(result._id)) {                                                           //
                    throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');                   //
                  }                                                                                                    //
                  opts._id = opts.fileId;                                                                              //
                  opts.createdAt = new Date();                                                                         //
                  opts.maxLength = opts.fileLength;                                                                    //
                  self._preCollection.insert(_.omit(opts, '___s'));                                                    //
                  self._createStream(result._id, result.path, _.omit(opts, '___s'));                                   //
                  if (opts.returnMeta) {                                                                               //
                    if (!response.headersSent) {                                                                       //
                      response.writeHead(200);                                                                         //
                    }                                                                                                  //
                    if (!response.finished) {                                                                          //
                      response.end(JSON.stringify({                                                                    //
                        uploadRoute: self.downloadRoute + "/" + self.collectionName + "/__upload",                     //
                        file: result                                                                                   //
                      }));                                                                                             //
                    }                                                                                                  //
                  } else {                                                                                             //
                    if (!response.headersSent) {                                                                       //
                      response.writeHead(204);                                                                         //
                    }                                                                                                  //
                    if (!response.finished) {                                                                          //
                      response.end();                                                                                  //
                    }                                                                                                  //
                  }                                                                                                    //
                }                                                                                                      //
              } catch (error1) {                                                                                       //
                error = error1;                                                                                        //
                handleError(error);                                                                                    //
              }                                                                                                        //
            });                                                                                                        //
          });                                                                                                          //
        } else {                                                                                                       //
          next();                                                                                                      //
        }                                                                                                              //
        return;                                                                                                        //
      }                                                                                                                //
      if (!self["public"]) {                                                                                           //
        if (!!~request._parsedUrl.path.indexOf(self.downloadRoute + "/" + self.collectionName)) {                      //
          uri = request._parsedUrl.path.replace(self.downloadRoute + "/" + self.collectionName, '');                   //
          if (uri.indexOf('/') === 0) {                                                                                //
            uri = uri.substring(1);                                                                                    //
          }                                                                                                            //
          uris = uri.split('/');                                                                                       //
          if (uris.length === 3) {                                                                                     //
            params = {                                                                                                 //
              query: request._parsedUrl.query ? nodeQs.parse(request._parsedUrl.query) : {},                           //
              _id: uris[0],                                                                                            //
              version: uris[1],                                                                                        //
              name: uris[2].split('?')[0]                                                                              //
            };                                                                                                         //
            http = {                                                                                                   //
              request: request,                                                                                        //
              response: response,                                                                                      //
              params: params                                                                                           //
            };                                                                                                         //
            if (self._checkAccess(http)) {                                                                             //
              self.download(http, uris[1], self.collection.findOne(uris[0]));                                          //
            }                                                                                                          //
          } else {                                                                                                     //
            next();                                                                                                    //
          }                                                                                                            //
        } else {                                                                                                       //
          next();                                                                                                      //
        }                                                                                                              //
      } else {                                                                                                         //
        if (!!~request._parsedUrl.path.indexOf("" + self.downloadRoute)) {                                             //
          uri = request._parsedUrl.path.replace("" + self.downloadRoute, '');                                          //
          if (uri.indexOf('/') === 0) {                                                                                //
            uri = uri.substring(1);                                                                                    //
          }                                                                                                            //
          uris = uri.split('/');                                                                                       //
          _file = uris[uris.length - 1];                                                                               //
          if (_file) {                                                                                                 //
            if (!!~_file.indexOf('-')) {                                                                               //
              version = _file.split('-')[0];                                                                           //
              _file = _file.split('-')[1].split('?')[0];                                                               //
            } else {                                                                                                   //
              version = 'original';                                                                                    //
              _file = _file.split('?')[0];                                                                             //
            }                                                                                                          //
            params = {                                                                                                 //
              query: request._parsedUrl.query ? nodeQs.parse(request._parsedUrl.query) : {},                           //
              file: _file,                                                                                             //
              _id: _file.split('.')[0],                                                                                //
              version: version,                                                                                        //
              name: _file                                                                                              //
            };                                                                                                         //
            http = {                                                                                                   //
              request: request,                                                                                        //
              response: response,                                                                                      //
              params: params                                                                                           //
            };                                                                                                         //
            self.download(http, version, self.collection.findOne(params._id));                                         //
          } else {                                                                                                     //
            next();                                                                                                    //
          }                                                                                                            //
        } else {                                                                                                       //
          next();                                                                                                      //
        }                                                                                                              //
      }                                                                                                                //
    });                                                                                                                //
    _methods = {};                                                                                                     //
    _methods[self._methodNames._Remove] = function (selector) {                                                        //
      var cursor, user, userFuncs;                                                                                     //
      check(selector, Match.OneOf(String, Object));                                                                    //
      self._debug("[FilesCollection] [Unlink Method] [.remove(" + selector + ")]");                                    //
      if (self.allowClientCode) {                                                                                      //
        if (self.onBeforeRemove && _.isFunction(self.onBeforeRemove)) {                                                //
          user = false;                                                                                                //
          userFuncs = {                                                                                                //
            userId: this.userId,                                                                                       //
            user: function () {                                                                                        //
              function user() {                                                                                        //
                if (Meteor.users) {                                                                                    //
                  return Meteor.users.findOne(this.userId);                                                            //
                } else {                                                                                               //
                  return null;                                                                                         //
                }                                                                                                      //
              }                                                                                                        //
                                                                                                                       //
              return user;                                                                                             //
            }()                                                                                                        //
          };                                                                                                           //
          if (!self.onBeforeRemove.call(userFuncs, self.find(selector) || null)) {                                     //
            throw new Meteor.Error(403, '[FilesCollection] [remove] Not permitted!');                                  //
          }                                                                                                            //
        }                                                                                                              //
        cursor = self.find(selector);                                                                                  //
        if (cursor.count() > 0) {                                                                                      //
          self.remove(selector);                                                                                       //
          return true;                                                                                                 //
        } else {                                                                                                       //
          throw new Meteor.Error(404, 'Cursor is empty, no files is removed');                                         //
        }                                                                                                              //
      } else {                                                                                                         //
        throw new Meteor.Error(401, '[FilesCollection] [remove] Run code from client is not allowed!');                //
      }                                                                                                                //
    };                                                                                                                 //
    _methods[self._methodNames._Start] = function (opts, returnMeta) {                                                 //
      var result;                                                                                                      //
      check(opts, {                                                                                                    //
        file: Object,                                                                                                  //
        fileId: String,                                                                                                //
        FSName: Match.Optional(String),                                                                                //
        chunkSize: Number,                                                                                             //
        fileLength: Number                                                                                             //
      });                                                                                                              //
      check(returnMeta, Match.Optional(Boolean));                                                                      //
      self._debug("[FilesCollection] [File Start Method] " + opts.file.name + " - " + opts.fileId);                    //
      opts.___s = true;                                                                                                //
      result = self._prepareUpload(_.clone(opts), this.userId, 'DDP Start Method').result;                             //
      if (self.collection.findOne(result._id)) {                                                                       //
        throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');                               //
      }                                                                                                                //
      opts._id = opts.fileId;                                                                                          //
      opts.createdAt = new Date();                                                                                     //
      opts.maxLength = opts.fileLength;                                                                                //
      self._preCollection.insert(_.omit(opts, '___s'));                                                                //
      self._createStream(result._id, result.path, _.omit(opts, '___s'));                                               //
      if (returnMeta) {                                                                                                //
        return {                                                                                                       //
          uploadRoute: self.downloadRoute + "/" + self.collectionName + "/__upload",                                   //
          file: result                                                                                                 //
        };                                                                                                             //
      } else {                                                                                                         //
        return true;                                                                                                   //
      }                                                                                                                //
    };                                                                                                                 //
    _methods[self._methodNames._Write] = function (opts) {                                                             //
      var _continueUpload, e, ref, result;                                                                             //
      check(opts, {                                                                                                    //
        eof: Match.Optional(Boolean),                                                                                  //
        fileId: String,                                                                                                //
        binData: Match.Optional(String),                                                                               //
        chunkId: Match.Optional(Number)                                                                                //
      });                                                                                                              //
      if (opts.binData) {                                                                                              //
        if (typeof Buffer.from === 'function') {                                                                       //
          try {                                                                                                        //
            opts.binData = Buffer.from(opts.binData, 'base64');                                                        //
          } catch (error1) {                                                                                           //
            e = error1;                                                                                                //
            opts.binData = new Buffer(opts.binData, 'base64');                                                         //
          }                                                                                                            //
        } else {                                                                                                       //
          opts.binData = new Buffer(opts.binData, 'base64');                                                           //
        }                                                                                                              //
      }                                                                                                                //
      _continueUpload = self._continueUpload(opts.fileId);                                                             //
      if (!_continueUpload) {                                                                                          //
        throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');                   //
      }                                                                                                                //
      this.unblock();                                                                                                  //
      ref = self._prepareUpload(_.extend(opts, _continueUpload), this.userId, 'DDP'), result = ref.result, opts = ref.opts;
      if (opts.eof) {                                                                                                  //
        try {                                                                                                          //
          return Meteor.wrapAsync(self._handleUpload.bind(self, result, opts))();                                      //
        } catch (error1) {                                                                                             //
          e = error1;                                                                                                  //
          self._debug("[FilesCollection] [Write Method] [DDP] Exception:", e);                                         //
          throw e;                                                                                                     //
        }                                                                                                              //
      } else {                                                                                                         //
        self.emit('_handleUpload', result, opts, NOOP);                                                                //
      }                                                                                                                //
      return true;                                                                                                     //
    };                                                                                                                 //
    _methods[self._methodNames._Abort] = function (_id) {                                                              //
      var _continueUpload, ref, ref1, ref2;                                                                            //
      check(_id, String);                                                                                              //
      _continueUpload = self._continueUpload(_id);                                                                     //
      self._debug("[FilesCollection] [Abort Method]: " + _id + " - " + (_continueUpload != null ? (ref = _continueUpload.file) != null ? ref.path : void 0 : void 0));
      if ((ref1 = self._currentUploads) != null ? ref1[_id] : void 0) {                                                //
        self._currentUploads[_id].stop();                                                                              //
        self._currentUploads[_id].abort();                                                                             //
      }                                                                                                                //
      if (_continueUpload) {                                                                                           //
        self._preCollection.remove({                                                                                   //
          _id: _id                                                                                                     //
        });                                                                                                            //
        self.remove({                                                                                                  //
          _id: _id                                                                                                     //
        });                                                                                                            //
        if (_continueUpload != null ? (ref2 = _continueUpload.file) != null ? ref2.path : void 0 : void 0) {           //
          self.unlink({                                                                                                //
            _id: _id,                                                                                                  //
            path: _continueUpload.file.path                                                                            //
          });                                                                                                          //
        }                                                                                                              //
      }                                                                                                                //
      return true;                                                                                                     //
    };                                                                                                                 //
    Meteor.methods(_methods);                                                                                          //
  }                                                                                                                    //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name _prepareUpload                                                                                                 //
  @summary Internal method. Used to optimize received data and check upload permission                                 //
  @returns {Object}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._prepareUpload = function (opts, userId, transport) {                                      //
    var base, ctx, extension, extensionWithDot, fileName, isUploadAllowed, ref, result;                                //
    if (opts.eof == null) {                                                                                            //
      opts.eof = false;                                                                                                //
    }                                                                                                                  //
    if (opts.binData == null) {                                                                                        //
      opts.binData = 'EOF';                                                                                            //
    }                                                                                                                  //
    if (opts.chunkId == null) {                                                                                        //
      opts.chunkId = -1;                                                                                               //
    }                                                                                                                  //
    if (opts.FSName == null) {                                                                                         //
      opts.FSName = opts.fileId;                                                                                       //
    }                                                                                                                  //
    this._debug("[FilesCollection] [Upload] [" + transport + "] Got #" + opts.chunkId + "/" + opts.fileLength + " chunks, dst: " + (opts.file.name || opts.file.fileName));
    fileName = this._getFileName(opts.file);                                                                           //
    ref = this._getExt(fileName), extension = ref.extension, extensionWithDot = ref.extensionWithDot;                  //
    if ((base = opts.file).meta == null) {                                                                             //
      base.meta = {};                                                                                                  //
    }                                                                                                                  //
    result = opts.file;                                                                                                //
    result.name = fileName;                                                                                            //
    result.meta = opts.file.meta;                                                                                      //
    result.extension = extension;                                                                                      //
    result.ext = extension;                                                                                            //
    result._id = opts.fileId;                                                                                          //
    result.userId = userId || null;                                                                                    //
    opts.FSName = opts.FSName.replace(/([^a-z0-9\-\_]+)/gi, '-');                                                      //
    result.path = "" + this.storagePath(result) + nodePath.sep + opts.FSName + extensionWithDot;                       //
    result = _.extend(result, this._dataToSchema(result));                                                             //
    if (this.onBeforeUpload && _.isFunction(this.onBeforeUpload)) {                                                    //
      ctx = _.extend({                                                                                                 //
        file: opts.file                                                                                                //
      }, {                                                                                                             //
        chunkId: opts.chunkId,                                                                                         //
        userId: result.userId,                                                                                         //
        user: function () {                                                                                            //
          function user() {                                                                                            //
            if (Meteor.users && result.userId) {                                                                       //
              return Meteor.users.findOne(result.userId);                                                              //
            } else {                                                                                                   //
              return null;                                                                                             //
            }                                                                                                          //
          }                                                                                                            //
                                                                                                                       //
          return user;                                                                                                 //
        }(),                                                                                                           //
        eof: opts.eof                                                                                                  //
      });                                                                                                              //
      isUploadAllowed = this.onBeforeUpload.call(ctx, result);                                                         //
      if (isUploadAllowed !== true) {                                                                                  //
        throw new Meteor.Error(403, _.isString(isUploadAllowed) ? isUploadAllowed : '@onBeforeUpload() returned false');
      } else {                                                                                                         //
        if (opts.___s === true && this.onInitiateUpload && _.isFunction(this.onInitiateUpload)) {                      //
          this.onInitiateUpload.call(ctx, result);                                                                     //
        }                                                                                                              //
      }                                                                                                                //
    } else if (opts.___s === true && this.onInitiateUpload && _.isFunction(this.onInitiateUpload)) {                   //
      ctx = _.extend({                                                                                                 //
        file: opts.file                                                                                                //
      }, {                                                                                                             //
        chunkId: opts.chunkId,                                                                                         //
        userId: result.userId,                                                                                         //
        user: function () {                                                                                            //
          function user() {                                                                                            //
            if (Meteor.users && result.userId) {                                                                       //
              return Meteor.users.findOne(result.userId);                                                              //
            } else {                                                                                                   //
              return null;                                                                                             //
            }                                                                                                          //
          }                                                                                                            //
                                                                                                                       //
          return user;                                                                                                 //
        }(),                                                                                                           //
        eof: opts.eof                                                                                                  //
      });                                                                                                              //
      this.onInitiateUpload.call(ctx, result);                                                                         //
    }                                                                                                                  //
    return {                                                                                                           //
      result: result,                                                                                                  //
      opts: opts                                                                                                       //
    };                                                                                                                 //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name _finishUpload                                                                                                  //
  @summary Internal method. Finish upload, close Writable stream, add record to MongoDB and flush used memory          //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._finishUpload = function (result, opts, cb) {                                              //
    var self;                                                                                                          //
    this._debug("[FilesCollection] [Upload] [finish(ing)Upload] -> " + result.path);                                   //
    fs.chmod(result.path, this.permissions, NOOP);                                                                     //
    self = this;                                                                                                       //
    result.type = this._getMimeType(opts.file);                                                                        //
    result["public"] = this["public"];                                                                                 //
    this._updateFileTypes(result);                                                                                     //
    this.collection.insert(_.clone(result), function (error, _id) {                                                    //
      if (error) {                                                                                                     //
        cb && cb(error);                                                                                               //
        self._debug('[FilesCollection] [Upload] [_finishUpload] Error:', error);                                       //
      } else {                                                                                                         //
        self._preCollection.update({                                                                                   //
          _id: opts.fileId                                                                                             //
        }, {                                                                                                           //
          $set: {                                                                                                      //
            isFinished: true                                                                                           //
          }                                                                                                            //
        });                                                                                                            //
        result._id = _id;                                                                                              //
        self._debug("[FilesCollection] [Upload] [finish(ed)Upload] -> " + result.path);                                //
        self.onAfterUpload && self.onAfterUpload.call(self, result);                                                   //
        self.emit('afterUpload', result);                                                                              //
        cb && cb(null, result);                                                                                        //
      }                                                                                                                //
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name _handleUpload                                                                                                  //
  @summary Internal method to handle upload process, pipe incoming data to Writable stream                             //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._handleUpload = function (result, opts, cb) {                                              //
    var e, self;                                                                                                       //
    try {                                                                                                              //
      if (opts.eof) {                                                                                                  //
        self = this;                                                                                                   //
        this._currentUploads[result._id].end(function () {                                                             //
          self.emit('_finishUpload', result, opts, cb);                                                                //
        });                                                                                                            //
      } else {                                                                                                         //
        this._currentUploads[result._id].write(opts.chunkId, opts.binData, cb);                                        //
      }                                                                                                                //
    } catch (error1) {                                                                                                 //
      e = error1;                                                                                                      //
      this._debug("[_handleUpload] [EXCEPTION:]", e);                                                                  //
      cb && cb(e);                                                                                                     //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _getMimeType                                                                                                   //
  @param {Object} fileData - File Object                                                                               //
  @summary Returns file's mime-type                                                                                    //
  @returns {String}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._getMimeType = function (fileData) {                                                       //
    var br, buf, error, ext, fd, mime, ref;                                                                            //
    check(fileData, Object);                                                                                           //
    if (fileData != null ? fileData.type : void 0) {                                                                   //
      mime = fileData.type;                                                                                            //
    }                                                                                                                  //
    if (fileData.path && (!mime || !_.isString(mime))) {                                                               //
      try {                                                                                                            //
        buf = new Buffer(262);                                                                                         //
        fd = fs.openSync(fileData.path, 'r');                                                                          //
        br = fs.readSync(fd, buf, 0, 262, 0);                                                                          //
        fs.close(fd, NOOP);                                                                                            //
        if (br < 262) {                                                                                                //
          buf = buf.slice(0, br);                                                                                      //
        }                                                                                                              //
        ref = fileType(buf), mime = ref.mime, ext = ref.ext;                                                           //
      } catch (error1) {                                                                                               //
        error = error1;                                                                                                //
      }                                                                                                                //
    }                                                                                                                  //
    if (!mime || !_.isString(mime)) {                                                                                  //
      mime = 'application/octet-stream';                                                                               //
    }                                                                                                                  //
    return mime;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _getUser                                                                                                       //
  @summary Returns object with `userId` and `user()` method which return user's object                                 //
  @returns {Object}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._getUser = function (http) {                                                               //
    var cookie, mtok, ref, ref1, result, userId;                                                                       //
    result = {                                                                                                         //
      user: function () {                                                                                              //
        function user() {                                                                                              //
          return null;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return user;                                                                                                   //
      }(),                                                                                                             //
      userId: null                                                                                                     //
    };                                                                                                                 //
    if (http) {                                                                                                        //
      mtok = null;                                                                                                     //
      if (http.request.headers['x-mtok']) {                                                                            //
        mtok = http.request.headers['x-mtok'];                                                                         //
      } else {                                                                                                         //
        cookie = http.request.Cookies;                                                                                 //
        if (cookie.has('x_mtok')) {                                                                                    //
          mtok = cookie.get('x_mtok');                                                                                 //
        }                                                                                                              //
      }                                                                                                                //
      if (mtok) {                                                                                                      //
        userId = (ref = Meteor.server.sessions) != null ? (ref1 = ref[mtok]) != null ? ref1.userId : void 0 : void 0;  //
        if (userId) {                                                                                                  //
          result.user = function () {                                                                                  //
            return Meteor.users.findOne(userId);                                                                       //
          };                                                                                                           //
          result.userId = userId;                                                                                      //
        }                                                                                                              //
      }                                                                                                                //
    }                                                                                                                  //
    return result;                                                                                                     //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name write                                                                                                          //
  @param {Buffer} buffer - Binary File's Buffer                                                                        //
  @param {Object} opts - Object with file-data                                                                         //
  @param {String} opts.name - File name, alias: `fileName`                                                             //
  @param {String} opts.type - File mime-type                                                                           //
  @param {Object} opts.meta - File additional meta-data                                                                //
  @param {String} opts.userId - UserId, default *null*                                                                 //
  @param {String} opts.fileId - _id, default *null*                                                                    //
  @param {Function} callback - function(error, fileObj){...}                                                           //
  @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook                                                     //
  @summary Write buffer to FS and add to FilesCollection Collection                                                    //
  @returns {FilesCollection} Instance                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.write = function (buffer, opts, callback, proceedAfterUpload) {                            //
    var FSName, extension, extensionWithDot, fileId, fileName, ref, result, self, stream;                              //
    if (opts == null) {                                                                                                //
      opts = {};                                                                                                       //
    }                                                                                                                  //
    this._debug('[FilesCollection] [write()]');                                                                        //
    if (_.isFunction(opts)) {                                                                                          //
      proceedAfterUpload = callback;                                                                                   //
      callback = opts;                                                                                                 //
      opts = {};                                                                                                       //
    } else if (_.isBoolean(callback)) {                                                                                //
      proceedAfterUpload = callback;                                                                                   //
    } else if (_.isBoolean(opts)) {                                                                                    //
      proceedAfterUpload = opts;                                                                                       //
    }                                                                                                                  //
    check(opts, Match.Optional(Object));                                                                               //
    check(callback, Match.Optional(Function));                                                                         //
    check(proceedAfterUpload, Match.Optional(Boolean));                                                                //
    fileId = opts.fileId || Random.id();                                                                               //
    FSName = this.namingFunction ? this.namingFunction(opts) : fileId;                                                 //
    fileName = opts.name || opts.fileName ? opts.name || opts.fileName : FSName;                                       //
    ref = this._getExt(fileName), extension = ref.extension, extensionWithDot = ref.extensionWithDot;                  //
    self = this;                                                                                                       //
    if (opts == null) {                                                                                                //
      opts = {};                                                                                                       //
    }                                                                                                                  //
    opts.path = "" + this.storagePath(opts) + nodePath.sep + FSName + extensionWithDot;                                //
    opts.type = this._getMimeType(opts);                                                                               //
    if (opts.meta == null) {                                                                                           //
      opts.meta = {};                                                                                                  //
    }                                                                                                                  //
    if (opts.size == null) {                                                                                           //
      opts.size = buffer.length;                                                                                       //
    }                                                                                                                  //
    result = this._dataToSchema({                                                                                      //
      name: fileName,                                                                                                  //
      path: opts.path,                                                                                                 //
      meta: opts.meta,                                                                                                 //
      type: opts.type,                                                                                                 //
      size: opts.size,                                                                                                 //
      userId: opts.userId,                                                                                             //
      extension: extension                                                                                             //
    });                                                                                                                //
    result._id = fileId;                                                                                               //
    stream = fs.createWriteStream(opts.path, {                                                                         //
      flags: 'w',                                                                                                      //
      mode: this.permissions                                                                                           //
    });                                                                                                                //
    stream.end(buffer, function (error) {                                                                              //
      return bound(function () {                                                                                       //
        if (error) {                                                                                                   //
          callback && callback(error);                                                                                 //
        } else {                                                                                                       //
          self.collection.insert(result, function (error, _id) {                                                       //
            var fileRef;                                                                                               //
            if (error) {                                                                                               //
              callback && callback(error);                                                                             //
              self._debug("[FilesCollection] [write] [insert] Error: " + fileName + " -> " + self.collectionName, error);
            } else {                                                                                                   //
              fileRef = self.collection.findOne(_id);                                                                  //
              callback && callback(null, fileRef);                                                                     //
              if (proceedAfterUpload === true) {                                                                       //
                self.onAfterUpload && self.onAfterUpload.call(self, fileRef);                                          //
                self.emit('afterUpload', fileRef);                                                                     //
              }                                                                                                        //
              self._debug("[FilesCollection] [write]: " + fileName + " -> " + self.collectionName);                    //
            }                                                                                                          //
          });                                                                                                          //
        }                                                                                                              //
      });                                                                                                              //
    });                                                                                                                //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name load                                                                                                           //
  @param {String} url - URL to file                                                                                    //
  @param {Object} opts - Object with file-data                                                                         //
  @param {String} opts.name - File name, alias: `fileName`                                                             //
  @param {String} opts.type - File mime-type                                                                           //
  @param {Object} opts.meta - File additional meta-data                                                                //
  @param {String} opts.userId - UserId, default *null*                                                                 //
  @param {String} opts.fileId - _id, default *null*                                                                    //
  @param {Function} callback - function(error, fileObj){...}                                                           //
  @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook                                                     //
  @summary Download file, write stream to FS and add to FilesCollection Collection                                     //
  @returns {FilesCollection} Instance                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.load = function (url, opts, callback, proceedAfterUpload) {                                //
    var FSName, extension, extensionWithDot, fileId, fileName, pathParts, ref, self, storeResult;                      //
    this._debug("[FilesCollection] [load(" + url + ", " + JSON.stringify(opts) + ", callback)]");                      //
    if (_.isFunction(opts)) {                                                                                          //
      proceedAfterUpload = callback;                                                                                   //
      callback = opts;                                                                                                 //
      opts = {};                                                                                                       //
    } else if (_.isBoolean(callback)) {                                                                                //
      proceedAfterUpload = callback;                                                                                   //
    } else if (_.isBoolean(opts)) {                                                                                    //
      proceedAfterUpload = opts;                                                                                       //
    }                                                                                                                  //
    check(url, String);                                                                                                //
    check(opts, Match.Optional(Object));                                                                               //
    check(callback, Match.Optional(Function));                                                                         //
    check(proceedAfterUpload, Match.Optional(Boolean));                                                                //
    self = this;                                                                                                       //
    if (opts == null) {                                                                                                //
      opts = {};                                                                                                       //
    }                                                                                                                  //
    fileId = opts.fileId || Random.id();                                                                               //
    FSName = this.namingFunction ? this.namingFunction(opts) : fileId;                                                 //
    pathParts = url.split('/');                                                                                        //
    fileName = opts.name || opts.fileName ? opts.name || opts.fileName : pathParts[pathParts.length - 1] || FSName;    //
    ref = this._getExt(fileName), extension = ref.extension, extensionWithDot = ref.extensionWithDot;                  //
    if (opts.meta == null) {                                                                                           //
      opts.meta = {};                                                                                                  //
    }                                                                                                                  //
    opts.path = "" + this.storagePath(opts) + nodePath.sep + FSName + extensionWithDot;                                //
    storeResult = function storeResult(result, callback) {                                                             //
      result._id = fileId;                                                                                             //
      self.collection.insert(result, function (error, _id) {                                                           //
        var fileRef;                                                                                                   //
        if (error) {                                                                                                   //
          callback && callback(error);                                                                                 //
          self._debug("[FilesCollection] [load] [insert] Error: " + fileName + " -> " + self.collectionName, error);   //
        } else {                                                                                                       //
          fileRef = self.collection.findOne(_id);                                                                      //
          callback && callback(null, fileRef);                                                                         //
          if (proceedAfterUpload === true) {                                                                           //
            self.onAfterUpload && self.onAfterUpload.call(self, fileRef);                                              //
            self.emit('afterUpload', fileRef);                                                                         //
          }                                                                                                            //
          self._debug("[FilesCollection] [load] [insert] " + fileName + " -> " + self.collectionName);                 //
        }                                                                                                              //
      });                                                                                                              //
    };                                                                                                                 //
    request.get(url).on('error', function (error) {                                                                    //
      return bound(function () {                                                                                       //
        callback && callback(error);                                                                                   //
        return self._debug("[FilesCollection] [load] [request.get(" + url + ")] Error:", error);                       //
      });                                                                                                              //
    }).on('response', function (response) {                                                                            //
      return bound(function () {                                                                                       //
        response.on('end', function () {                                                                               //
          return bound(function () {                                                                                   //
            var result;                                                                                                //
            self._debug("[FilesCollection] [load] Received: " + url);                                                  //
            result = self._dataToSchema({                                                                              //
              name: fileName,                                                                                          //
              path: opts.path,                                                                                         //
              meta: opts.meta,                                                                                         //
              type: opts.type || response.headers['content-type'] || self._getMimeType({                               //
                path: opts.path                                                                                        //
              }),                                                                                                      //
              size: opts.size || parseInt(response.headers['content-length'] || 0),                                    //
              userId: opts.userId,                                                                                     //
              extension: extension                                                                                     //
            });                                                                                                        //
            if (!result.size) {                                                                                        //
              fs.stat(opts.path, function (error, stats) {                                                             //
                return bound(function () {                                                                             //
                  if (error) {                                                                                         //
                    callback && callback(error);                                                                       //
                  } else {                                                                                             //
                    result.versions.original.size = result.size = stats.size;                                          //
                    storeResult(result, callback);                                                                     //
                  }                                                                                                    //
                });                                                                                                    //
              });                                                                                                      //
            } else {                                                                                                   //
              storeResult(result, callback);                                                                           //
            }                                                                                                          //
          });                                                                                                          //
        });                                                                                                            //
      });                                                                                                              //
    }).pipe(fs.createWriteStream(opts.path, {                                                                          //
      flags: 'w',                                                                                                      //
      mode: this.permissions                                                                                           //
    }));                                                                                                               //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name addFile                                                                                                        //
  @param {String} path          - Path to file                                                                         //
  @param {String} opts          - [Optional] Object with file-data                                                     //
  @param {String} opts.type     - [Optional] File mime-type                                                            //
  @param {Object} opts.meta     - [Optional] File additional meta-data                                                 //
  @param {Object} opts.fileName - [Optional] File name, if not specified file name and extension will be taken from path
  @param {String} opts.userId   - [Optional] UserId, default *null*                                                    //
  @param {Function} callback    - [Optional] function(error, fileObj){...}                                             //
  @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook                                                     //
  @summary Add file from FS to FilesCollection                                                                         //
  @returns {FilesCollection} Instance                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.addFile = function (path, opts, callback, proceedAfterUpload) {                            //
    var self;                                                                                                          //
    this._debug("[FilesCollection] [addFile(" + path + ")]");                                                          //
    if (_.isFunction(opts)) {                                                                                          //
      proceedAfterUpload = callback;                                                                                   //
      callback = opts;                                                                                                 //
      opts = {};                                                                                                       //
    } else if (_.isBoolean(callback)) {                                                                                //
      proceedAfterUpload = callback;                                                                                   //
    } else if (_.isBoolean(opts)) {                                                                                    //
      proceedAfterUpload = opts;                                                                                       //
    }                                                                                                                  //
    if (this["public"]) {                                                                                              //
      throw new Meteor.Error(403, 'Can not run [addFile] on public collection! Just Move file to root of your server, then add record to Collection');
    }                                                                                                                  //
    check(path, String);                                                                                               //
    check(opts, Match.Optional(Object));                                                                               //
    check(callback, Match.Optional(Function));                                                                         //
    check(proceedAfterUpload, Match.Optional(Boolean));                                                                //
    self = this;                                                                                                       //
    fs.stat(path, function (error, stats) {                                                                            //
      return bound(function () {                                                                                       //
        var extension, extensionWithDot, pathParts, ref, result;                                                       //
        if (error) {                                                                                                   //
          callback && callback(error);                                                                                 //
        } else if (stats.isFile()) {                                                                                   //
          if (opts == null) {                                                                                          //
            opts = {};                                                                                                 //
          }                                                                                                            //
          opts.path = path;                                                                                            //
          if (!opts.fileName) {                                                                                        //
            pathParts = path.split(nodePath.sep);                                                                      //
            opts.fileName = pathParts[pathParts.length - 1];                                                           //
          }                                                                                                            //
          ref = self._getExt(opts.fileName), extension = ref.extension, extensionWithDot = ref.extensionWithDot;       //
          if (opts.type == null) {                                                                                     //
            opts.type = self._getMimeType(opts);                                                                       //
          }                                                                                                            //
          if (opts.meta == null) {                                                                                     //
            opts.meta = {};                                                                                            //
          }                                                                                                            //
          if (opts.size == null) {                                                                                     //
            opts.size = stats.size;                                                                                    //
          }                                                                                                            //
          result = self._dataToSchema({                                                                                //
            name: opts.fileName,                                                                                       //
            path: path,                                                                                                //
            meta: opts.meta,                                                                                           //
            type: opts.type,                                                                                           //
            size: opts.size,                                                                                           //
            userId: opts.userId,                                                                                       //
            extension: extension,                                                                                      //
            _storagePath: path.replace("" + nodePath.sep + opts.fileName, ''),                                         //
            fileId: opts.fileId || null                                                                                //
          });                                                                                                          //
          self.collection.insert(result, function (error, _id) {                                                       //
            var fileRef;                                                                                               //
            if (error) {                                                                                               //
              callback && callback(error);                                                                             //
              self._debug("[FilesCollection] [addFile] [insert] Error: " + result.name + " -> " + self.collectionName, error);
            } else {                                                                                                   //
              fileRef = self.collection.findOne(_id);                                                                  //
              callback && callback(null, fileRef);                                                                     //
              if (proceedAfterUpload === true) {                                                                       //
                self.onAfterUpload && self.onAfterUpload.call(self, fileRef);                                          //
                self.emit('afterUpload', fileRef);                                                                     //
              }                                                                                                        //
              self._debug("[FilesCollection] [addFile]: " + result.name + " -> " + self.collectionName);               //
            }                                                                                                          //
          });                                                                                                          //
        } else {                                                                                                       //
          callback && callback(new Meteor.Error(400, "[FilesCollection] [addFile(" + path + ")]: File does not exist"));
        }                                                                                                              //
      });                                                                                                              //
    });                                                                                                                //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name remove                                                                                                         //
  @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)       //
  @param {Function} callback - Callback with one `error` argument                                                      //
  @summary Remove documents from the collection                                                                        //
  @returns {FilesCollection} Instance                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.remove = function (selector, callback) {                                                   //
    var docs, files, self;                                                                                             //
    if (selector == null) {                                                                                            //
      selector = {};                                                                                                   //
    }                                                                                                                  //
    this._debug("[FilesCollection] [remove(" + JSON.stringify(selector) + ")]");                                       //
    check(selector, Match.OneOf(Object, String));                                                                      //
    check(callback, Match.Optional(Function));                                                                         //
    files = this.collection.find(selector);                                                                            //
    if (files.count() > 0) {                                                                                           //
      self = this;                                                                                                     //
      files.forEach(function (file) {                                                                                  //
        self.unlink(file);                                                                                             //
      });                                                                                                              //
    } else {                                                                                                           //
      callback && callback(new Meteor.Error(404, 'Cursor is empty, no files is removed'));                             //
      return this;                                                                                                     //
    }                                                                                                                  //
    if (this.onAfterRemove) {                                                                                          //
      self = this;                                                                                                     //
      docs = files.fetch();                                                                                            //
      this.collection.remove(selector, function () {                                                                   //
        callback && callback.apply(this, arguments);                                                                   //
        self.onAfterRemove(docs);                                                                                      //
      });                                                                                                              //
    } else {                                                                                                           //
      this.collection.remove(selector, callback || NOOP);                                                              //
    }                                                                                                                  //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name deny                                                                                                           //
  @param {Object} rules                                                                                                //
  @see  https://docs.meteor.com/api/collections.html#Mongo-Collection-deny                                             //
  @summary link Mongo.Collection deny methods                                                                          //
  @returns {Mongo.Collection} Instance                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.deny = function (rules) {                                                                  //
    this.collection.deny(rules);                                                                                       //
    return this.collection;                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name allow                                                                                                          //
  @param {Object} rules                                                                                                //
  @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow                                             //
  @summary link Mongo.Collection allow methods                                                                         //
  @returns {Mongo.Collection} Instance                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.allow = function (rules) {                                                                 //
    this.collection.allow(rules);                                                                                      //
    return this.collection;                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name denyClient                                                                                                     //
  @see https://docs.meteor.com/api/collections.html#Mongo-Collection-deny                                              //
  @summary Shorthands for Mongo.Collection deny method                                                                 //
  @returns {Mongo.Collection} Instance                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.denyClient = function () {                                                                 //
    this.collection.deny({                                                                                             //
      insert: function () {                                                                                            //
        function insert() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return insert;                                                                                                 //
      }(),                                                                                                             //
      update: function () {                                                                                            //
        function update() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return update;                                                                                                 //
      }(),                                                                                                             //
      remove: function () {                                                                                            //
        function remove() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return remove;                                                                                                 //
      }()                                                                                                              //
    });                                                                                                                //
    return this.collection;                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name allowClient                                                                                                    //
  @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow                                             //
  @summary Shorthands for Mongo.Collection allow method                                                                //
  @returns {Mongo.Collection} Instance                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.allowClient = function () {                                                                //
    this.collection.allow({                                                                                            //
      insert: function () {                                                                                            //
        function insert() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return insert;                                                                                                 //
      }(),                                                                                                             //
      update: function () {                                                                                            //
        function update() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return update;                                                                                                 //
      }(),                                                                                                             //
      remove: function () {                                                                                            //
        function remove() {                                                                                            //
          return true;                                                                                                 //
        }                                                                                                              //
                                                                                                                       //
        return remove;                                                                                                 //
      }()                                                                                                              //
    });                                                                                                                //
    return this.collection;                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name unlink                                                                                                         //
  @param {Object} fileRef - fileObj                                                                                    //
  @param {String} version - [Optional] file's version                                                                  //
  @param {Function} callback - [Optional] callback function                                                            //
  @summary Unlink files and it's versions from FS                                                                      //
  @returns {FilesCollection} Instance                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.unlink = function (fileRef, version, callback) {                                           //
    var ref, ref1;                                                                                                     //
    this._debug("[FilesCollection] [unlink(" + fileRef._id + ", " + version + ")]");                                   //
    if (version) {                                                                                                     //
      if (((ref = fileRef.versions) != null ? ref[version] : void 0) && ((ref1 = fileRef.versions[version]) != null ? ref1.path : void 0)) {
        fs.unlink(fileRef.versions[version].path, callback || NOOP);                                                   //
      }                                                                                                                //
    } else {                                                                                                           //
      if (fileRef.versions && !_.isEmpty(fileRef.versions)) {                                                          //
        _.each(fileRef.versions, function (vRef) {                                                                     //
          return bound(function () {                                                                                   //
            fs.unlink(vRef.path, callback || NOOP);                                                                    //
          });                                                                                                          //
        });                                                                                                            //
      } else {                                                                                                         //
        fs.unlink(fileRef.path, callback || NOOP);                                                                     //
      }                                                                                                                //
    }                                                                                                                  //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name _404                                                                                                           //
  @summary Internal method, used to return 404 error                                                                   //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype._404 = function (http) {                                                                   //
    var text;                                                                                                          //
    this._debug("[FilesCollection] [download(" + http.request.originalUrl + ")] [_404] File not found");               //
    text = 'File Not Found :(';                                                                                        //
    if (!http.response.headersSent) {                                                                                  //
      http.response.writeHead(404, {                                                                                   //
        'Content-Length': text.length,                                                                                 //
        'Content-Type': 'text/plain'                                                                                   //
      });                                                                                                              //
    }                                                                                                                  //
    if (!http.response.finished) {                                                                                     //
      http.response.end(text);                                                                                         //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name download                                                                                                       //
  @param {Object} http    - Server HTTP object                                                                         //
  @param {String} version - Requested file version                                                                     //
  @param {Object} fileRef - Requested file Object                                                                      //
  @summary Initiates the HTTP response                                                                                 //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.download = function (http, version, fileRef) {                                             //
    var self, vRef;                                                                                                    //
    if (version == null) {                                                                                             //
      version = 'original';                                                                                            //
    }                                                                                                                  //
    this._debug("[FilesCollection] [download(" + http.request.originalUrl + ", " + version + ")]");                    //
    if (fileRef) {                                                                                                     //
      if (_.has(fileRef, 'versions') && _.has(fileRef.versions, version)) {                                            //
        vRef = fileRef.versions[version];                                                                              //
        vRef._id = fileRef._id;                                                                                        //
      } else {                                                                                                         //
        vRef = fileRef;                                                                                                //
      }                                                                                                                //
    } else {                                                                                                           //
      vRef = false;                                                                                                    //
    }                                                                                                                  //
    if (!vRef || !_.isObject(vRef)) {                                                                                  //
      return this._404(http);                                                                                          //
    } else if (fileRef) {                                                                                              //
      self = this;                                                                                                     //
      if (this.downloadCallback) {                                                                                     //
        if (!this.downloadCallback.call(_.extend(http, this._getUser(http)), fileRef)) {                               //
          return this._404(http);                                                                                      //
        }                                                                                                              //
      }                                                                                                                //
      if (this.interceptDownload && _.isFunction(this.interceptDownload)) {                                            //
        if (this.interceptDownload(http, fileRef, version) === true) {                                                 //
          return;                                                                                                      //
        }                                                                                                              //
      }                                                                                                                //
      fs.stat(vRef.path, function (statErr, stats) {                                                                   //
        return bound(function () {                                                                                     //
          var responseType;                                                                                            //
          if (statErr || !stats.isFile()) {                                                                            //
            return self._404(http);                                                                                    //
          }                                                                                                            //
          if (stats.size !== vRef.size && !self.integrityCheck) {                                                      //
            vRef.size = stats.size;                                                                                    //
          }                                                                                                            //
          if (stats.size !== vRef.size && self.integrityCheck) {                                                       //
            responseType = '400';                                                                                      //
          }                                                                                                            //
          return self.serve(http, fileRef, vRef, version, null, responseType || '200');                                //
        });                                                                                                            //
      });                                                                                                              //
    } else {                                                                                                           //
      return this._404(http);                                                                                          //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Server                                                                                                        //
  @memberOf FilesCollection                                                                                            //
  @name serve                                                                                                          //
  @param {Object} http    - Server HTTP object                                                                         //
  @param {Object} fileRef - Requested file Object                                                                      //
  @param {Object} vRef    - Requested file version Object                                                              //
  @param {String} version - Requested file version                                                                     //
  @param {stream.Readable|null} readableStream - Readable stream, which serves binary file data                        //
  @param {String} responseType - Response code                                                                         //
  @param {Boolean} force200 - Force 200 response code over 206                                                         //
  @summary Handle and reply to incoming request                                                                        //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollection.prototype.serve = function (http, fileRef, vRef, version, readableStream, responseType, force200) {  //
    var array, dispositionEncoding, dispositionName, dispositionType, end, headers, key, partiral, reqRange, self, start, stream, streamErrorHandler, take, text, value;
    if (version == null) {                                                                                             //
      version = 'original';                                                                                            //
    }                                                                                                                  //
    if (readableStream == null) {                                                                                      //
      readableStream = null;                                                                                           //
    }                                                                                                                  //
    if (responseType == null) {                                                                                        //
      responseType = '200';                                                                                            //
    }                                                                                                                  //
    if (force200 == null) {                                                                                            //
      force200 = false;                                                                                                //
    }                                                                                                                  //
    self = this;                                                                                                       //
    partiral = false;                                                                                                  //
    reqRange = false;                                                                                                  //
    if (http.params.query.download && http.params.query.download === 'true') {                                         //
      dispositionType = 'attachment; ';                                                                                //
    } else {                                                                                                           //
      dispositionType = 'inline; ';                                                                                    //
    }                                                                                                                  //
    dispositionName = "filename=\"" + encodeURI(vRef.name || fileRef.name) + "\"; filename*=UTF-8''" + encodeURI(vRef.name || fileRef.name) + "; ";
    dispositionEncoding = 'charset=UTF-8';                                                                             //
    if (!http.response.headersSent) {                                                                                  //
      http.response.setHeader('Content-Disposition', dispositionType + dispositionName + dispositionEncoding);         //
    }                                                                                                                  //
    if (http.request.headers.range && !force200) {                                                                     //
      partiral = true;                                                                                                 //
      array = http.request.headers.range.split(/bytes=([0-9]*)-([0-9]*)/);                                             //
      start = parseInt(array[1]);                                                                                      //
      end = parseInt(array[2]);                                                                                        //
      if (isNaN(end)) {                                                                                                //
        end = vRef.size - 1;                                                                                           //
      }                                                                                                                //
      take = end - start;                                                                                              //
    } else {                                                                                                           //
      start = 0;                                                                                                       //
      end = vRef.size - 1;                                                                                             //
      take = vRef.size;                                                                                                //
    }                                                                                                                  //
    if (partiral || http.params.query.play && http.params.query.play === 'true') {                                     //
      reqRange = {                                                                                                     //
        start: start,                                                                                                  //
        end: end                                                                                                       //
      };                                                                                                               //
      if (isNaN(start) && !isNaN(end)) {                                                                               //
        reqRange.start = end - take;                                                                                   //
        reqRange.end = end;                                                                                            //
      }                                                                                                                //
      if (!isNaN(start) && isNaN(end)) {                                                                               //
        reqRange.start = start;                                                                                        //
        reqRange.end = start + take;                                                                                   //
      }                                                                                                                //
      if (start + take >= vRef.size) {                                                                                 //
        reqRange.end = vRef.size - 1;                                                                                  //
      }                                                                                                                //
      if (self.strict && (reqRange.start >= vRef.size - 1 || reqRange.end > vRef.size - 1)) {                          //
        responseType = '416';                                                                                          //
      } else {                                                                                                         //
        responseType = '206';                                                                                          //
      }                                                                                                                //
    } else {                                                                                                           //
      responseType = '200';                                                                                            //
    }                                                                                                                  //
    streamErrorHandler = function streamErrorHandler(error) {                                                          //
      self._debug("[FilesCollection] [serve(" + vRef.path + ", " + version + ")] [500]", error);                       //
      if (!http.response.finished) {                                                                                   //
        http.response.end(error.toString());                                                                           //
      }                                                                                                                //
    };                                                                                                                 //
    headers = _.isFunction(self.responseHeaders) ? self.responseHeaders(responseType, fileRef, vRef, version) : self.responseHeaders;
    if (!headers['Cache-Control']) {                                                                                   //
      if (!http.response.headersSent) {                                                                                //
        http.response.setHeader('Cache-Control', self.cacheControl);                                                   //
      }                                                                                                                //
    }                                                                                                                  //
    for (key in meteorBabelHelpers.sanitizeForInObject(headers)) {                                                     //
      value = headers[key];                                                                                            //
      if (!http.response.headersSent) {                                                                                //
        http.response.setHeader(key, value);                                                                           //
      }                                                                                                                //
    }                                                                                                                  //
    switch (responseType) {                                                                                            //
      case '400':                                                                                                      //
        self._debug("[FilesCollection] [serve(" + vRef.path + ", " + version + ")] [400] Content-Length mismatch!");   //
        text = 'Content-Length mismatch!';                                                                             //
        if (!http.response.headersSent) {                                                                              //
          http.response.writeHead(400, {                                                                               //
            'Content-Type': 'text/plain',                                                                              //
            'Content-Length': text.length                                                                              //
          });                                                                                                          //
        }                                                                                                              //
        if (!http.response.finished) {                                                                                 //
          http.response.end(text);                                                                                     //
        }                                                                                                              //
        break;                                                                                                         //
      case '404':                                                                                                      //
        return self._404(http);                                                                                        //
        break;                                                                                                         //
      case '416':                                                                                                      //
        self._debug("[FilesCollection] [serve(" + vRef.path + ", " + version + ")] [416] Content-Range is not specified!");
        if (!http.response.headersSent) {                                                                              //
          http.response.writeHead(416);                                                                                //
        }                                                                                                              //
        if (!http.response.finished) {                                                                                 //
          http.response.end();                                                                                         //
        }                                                                                                              //
        break;                                                                                                         //
      case '200':                                                                                                      //
        self._debug("[FilesCollection] [serve(" + vRef.path + ", " + version + ")] [200]");                            //
        stream = readableStream || fs.createReadStream(vRef.path);                                                     //
        if (!http.response.headersSent) {                                                                              //
          if (readableStream) {                                                                                        //
            http.response.writeHead(200);                                                                              //
          }                                                                                                            //
        }                                                                                                              //
        http.response.on('close', function () {                                                                        //
          if (typeof stream.abort === "function") {                                                                    //
            stream.abort();                                                                                            //
          }                                                                                                            //
          if (typeof stream.end === "function") {                                                                      //
            stream.end();                                                                                              //
          }                                                                                                            //
        });                                                                                                            //
        http.request.on('abort', function () {                                                                         //
          if (typeof stream.abort === "function") {                                                                    //
            stream.abort();                                                                                            //
          }                                                                                                            //
          if (typeof stream.end === "function") {                                                                      //
            stream.end();                                                                                              //
          }                                                                                                            //
        });                                                                                                            //
        stream.on('open', function () {                                                                                //
          if (!http.response.headersSent) {                                                                            //
            http.response.writeHead(200);                                                                              //
          }                                                                                                            //
        }).on('abort', function () {                                                                                   //
          if (!http.response.finished) {                                                                               //
            http.response.end();                                                                                       //
          }                                                                                                            //
          if (!http.request.aborted) {                                                                                 //
            http.request.abort();                                                                                      //
          }                                                                                                            //
        }).on('error', streamErrorHandler).on('end', function () {                                                     //
          if (!http.response.finished) {                                                                               //
            http.response.end();                                                                                       //
          }                                                                                                            //
        });                                                                                                            //
        if (self.throttle) {                                                                                           //
          stream.pipe(new Throttle({                                                                                   //
            bps: self.throttle,                                                                                        //
            chunksize: self.chunkSize                                                                                  //
          }));                                                                                                         //
        }                                                                                                              //
        stream.pipe(http.response);                                                                                    //
        break;                                                                                                         //
      case '206':                                                                                                      //
        self._debug("[FilesCollection] [serve(" + vRef.path + ", " + version + ")] [206]");                            //
        if (!http.response.headersSent) {                                                                              //
          http.response.setHeader('Content-Range', "bytes " + reqRange.start + "-" + reqRange.end + "/" + vRef.size);  //
        }                                                                                                              //
        stream = readableStream || fs.createReadStream(vRef.path, {                                                    //
          start: reqRange.start,                                                                                       //
          end: reqRange.end                                                                                            //
        });                                                                                                            //
        if (!http.response.headersSent) {                                                                              //
          if (readableStream) {                                                                                        //
            http.response.writeHead(206);                                                                              //
          }                                                                                                            //
        }                                                                                                              //
        http.response.on('close', function () {                                                                        //
          if (typeof stream.abort === "function") {                                                                    //
            stream.abort();                                                                                            //
          }                                                                                                            //
          if (typeof stream.end === "function") {                                                                      //
            stream.end();                                                                                              //
          }                                                                                                            //
        });                                                                                                            //
        http.request.on('abort', function () {                                                                         //
          if (typeof stream.abort === "function") {                                                                    //
            stream.abort();                                                                                            //
          }                                                                                                            //
          if (typeof stream.end === "function") {                                                                      //
            stream.end();                                                                                              //
          }                                                                                                            //
        });                                                                                                            //
        stream.on('open', function () {                                                                                //
          if (!http.response.headersSent) {                                                                            //
            http.response.writeHead(206);                                                                              //
          }                                                                                                            //
        }).on('abort', function () {                                                                                   //
          if (!http.response.finished) {                                                                               //
            http.response.end();                                                                                       //
          }                                                                                                            //
          if (!http.request.aborted) {                                                                                 //
            http.request.abort();                                                                                      //
          }                                                                                                            //
        }).on('error', streamErrorHandler).on('end', function () {                                                     //
          if (!http.response.finished) {                                                                               //
            http.response.end();                                                                                       //
          }                                                                                                            //
        });                                                                                                            //
        if (self.throttle) {                                                                                           //
          stream.pipe(new Throttle({                                                                                   //
            bps: self.throttle,                                                                                        //
            chunksize: self.chunkSize                                                                                  //
          }));                                                                                                         //
        }                                                                                                              //
        stream.pipe(http.response);                                                                                    //
        break;                                                                                                         //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  return FilesCollection;                                                                                              //
}());                                                                                                                  //
                                                                                                                       //
/*                                                                                                                     //
Export the FilesCollection class                                                                                       //
 */                                                                                                                    //
                                                                                                                       //
Meteor.Files = FilesCollection;                                                                                        //
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"core.coffee":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/core.coffee                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = require("./core.coffee.js");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"core.coffee.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/core.coffee.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
module.export({FilesCollectionCore:function(){return FilesCollectionCore}});var FilesCursor,FileCursor;module.import('./cursor.coffee',{"FilesCursor":function(v){FilesCursor=v},"FileCursor":function(v){FileCursor=v}});var fixJSONParse,fixJSONStringify,formatFleURL;module.import('./lib.coffee',{"fixJSONParse":function(v){fixJSONParse=v},"fixJSONStringify":function(v){fixJSONStringify=v},"formatFleURL":function(v){formatFleURL=v}});
                                                                                                                       //
var FilesCollectionCore;                                                                                               //
                                                                                                                       //
module.runModuleSetters(FilesCollectionCore = function () {                                                            //
  function FilesCollectionCore() {}                                                                                    //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _getFileName                                                                                                   //
  @param {Object} fileData - File Object                                                                               //
  @summary Returns file's name                                                                                         //
  @returns {String}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype._getFileName = function (fileData) {                                                   //
    var fileName;                                                                                                      //
    fileName = fileData.name || fileData.fileName;                                                                     //
    if (_.isString(fileName) && fileName.length > 0) {                                                                 //
      return (fileData.name || fileData.fileName).replace(/\.\./g, '').replace(/\//g, '');                             //
    } else {                                                                                                           //
      return '';                                                                                                       //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _getExt                                                                                                        //
  @param {String} FileName - File name                                                                                 //
  @summary Get extension from FileName                                                                                 //
  @returns {Object}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype._getExt = function (fileName) {                                                        //
    var extension;                                                                                                     //
    if (!!~fileName.indexOf('.')) {                                                                                    //
      extension = (fileName.split('.').pop().split('?')[0] || '').toLowerCase();                                       //
      return {                                                                                                         //
        ext: extension,                                                                                                //
        extension: extension,                                                                                          //
        extensionWithDot: '.' + extension                                                                              //
      };                                                                                                               //
    } else {                                                                                                           //
      return {                                                                                                         //
        ext: '',                                                                                                       //
        extension: '',                                                                                                 //
        extensionWithDot: ''                                                                                           //
      };                                                                                                               //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _updateFileTypes                                                                                               //
  @param {Object} data - File data                                                                                     //
  @summary Internal method. Classify file based on 'type' field                                                        //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype._updateFileTypes = function (data) {                                                   //
    data.isVideo = /^video\//i.test(data.type);                                                                        //
    data.isAudio = /^audio\//i.test(data.type);                                                                        //
    data.isImage = /^image\//i.test(data.type);                                                                        //
    data.isText = /^text\//i.test(data.type);                                                                          //
    data.isJSON = /^application\/json$/i.test(data.type);                                                              //
    data.isPDF = /^application\/(x-)?pdf$/i.test(data.type);                                                           //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name _dataToSchema                                                                                                  //
  @param {Object} data - File data                                                                                     //
  @summary Internal method. Build object in accordance with default schema from File data                              //
  @returns {Object}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype._dataToSchema = function (data) {                                                      //
    var ds;                                                                                                            //
    ds = {                                                                                                             //
      name: data.name,                                                                                                 //
      extension: data.extension,                                                                                       //
      path: data.path,                                                                                                 //
      meta: data.meta,                                                                                                 //
      type: data.type,                                                                                                 //
      size: data.size,                                                                                                 //
      userId: data.userId || null,                                                                                     //
      versions: {                                                                                                      //
        original: {                                                                                                    //
          path: data.path,                                                                                             //
          size: data.size,                                                                                             //
          type: data.type,                                                                                             //
          extension: data.extension                                                                                    //
        }                                                                                                              //
      },                                                                                                               //
      _downloadRoute: data._downloadRoute || this.downloadRoute,                                                       //
      _collectionName: data._collectionName || this.collectionName                                                     //
    };                                                                                                                 //
    if (data.fileId) {                                                                                                 //
      ds._id = data.fileId;                                                                                            //
    }                                                                                                                  //
    this._updateFileTypes(ds);                                                                                         //
    ds._storagePath = data._storagePath || this.storagePath(_.extend(data, ds));                                       //
    return ds;                                                                                                         //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name findOne                                                                                                        //
  @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)       //
  @param {Object} options - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)  //
  @summary Find and return Cursor for matching document Object                                                         //
  @returns {FileCursor} Instance                                                                                       //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype.findOne = function (selector, options) {                                               //
    var doc;                                                                                                           //
    this._debug("[FilesCollection] [findOne(" + JSON.stringify(selector) + ", " + JSON.stringify(options) + ")]");     //
    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));                               //
    check(options, Match.Optional(Object));                                                                            //
    if (!arguments.length) {                                                                                           //
      selector = {};                                                                                                   //
    }                                                                                                                  //
    doc = this.collection.findOne(selector, options);                                                                  //
    if (doc) {                                                                                                         //
      return new FileCursor(doc, this);                                                                                //
    } else {                                                                                                           //
      return doc;                                                                                                      //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name find                                                                                                           //
  @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)       //
  @param {Object}        options  - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)
  @summary Find and return Cursor for matching documents                                                               //
  @returns {FilesCursor} Instance                                                                                      //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype.find = function (selector, options) {                                                  //
    this._debug("[FilesCollection] [find(" + JSON.stringify(selector) + ", " + JSON.stringify(options) + ")]");        //
    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));                               //
    check(options, Match.Optional(Object));                                                                            //
    if (!arguments.length) {                                                                                           //
      selector = {};                                                                                                   //
    }                                                                                                                  //
    return new FilesCursor(selector, options, this);                                                                   //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name update                                                                                                         //
  @see http://docs.meteor.com/#/full/update                                                                            //
  @summary link Mongo.Collection update method                                                                         //
  @returns {Mongo.Collection} Instance                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype.update = function () {                                                                 //
    this.collection.update.apply(this.collection, arguments);                                                          //
    return this.collection;                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCollection                                                                                            //
  @name link                                                                                                           //
  @param {Object} fileRef - File reference object                                                                      //
  @param {String} version - Version of file you would like to request                                                  //
  @summary Returns downloadable URL                                                                                    //
  @returns {String} Empty string returned in case if file not found in DB                                              //
   */                                                                                                                  //
                                                                                                                       //
  FilesCollectionCore.prototype.link = function (fileRef, version) {                                                   //
    if (version == null) {                                                                                             //
      version = 'original';                                                                                            //
    }                                                                                                                  //
    this._debug("[FilesCollection] [link(" + (fileRef != null ? fileRef._id : void 0) + ", " + version + ")]");        //
    check(fileRef, Object);                                                                                            //
    check(version, String);                                                                                            //
    if (!fileRef) {                                                                                                    //
      return '';                                                                                                       //
    }                                                                                                                  //
    return formatFleURL(fileRef, version);                                                                             //
  };                                                                                                                   //
                                                                                                                       //
  return FilesCollectionCore;                                                                                          //
}());                                                                                                                  //
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor.coffee":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/cursor.coffee                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = require("./cursor.coffee.js");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor.coffee.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/cursor.coffee.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
module.export({FilesCursor:function(){return FilesCursor},FileCursor:function(){return FileCursor}});                  //
/*                                                                                                                     //
@private                                                                                                               //
@locus Anywhere                                                                                                        //
@class FileCursor                                                                                                      //
@param _fileRef    {Object} - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)             //
@param _collection {FilesCollection} - FilesCollection Instance                                                        //
@summary Internal class, represents each record in `FilesCursor.each()` or document returned from `.findOne()` method  //
 */                                                                                                                    //
var FileCursor, FilesCursor;                                                                                           //
                                                                                                                       //
module.runModuleSetters(FileCursor = function () {                                                                     //
  function FileCursor(_fileRef, _collection) {                                                                         //
    var self;                                                                                                          //
    this._fileRef = _fileRef;                                                                                          //
    this._collection = _collection;                                                                                    //
    self = this;                                                                                                       //
    self = _.extend(self, this._fileRef);                                                                              //
  }                                                                                                                    //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FileCursor                                                                                                 //
  @name remove                                                                                                         //
  @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed                  //
  @summary Remove document                                                                                             //
  @returns {FileCursor}                                                                                                //
   */                                                                                                                  //
                                                                                                                       //
  FileCursor.prototype.remove = function (callback) {                                                                  //
    this._collection._debug('[FilesCollection] [FileCursor] [remove()]');                                              //
    if (this._fileRef) {                                                                                               //
      this._collection.remove(this._fileRef._id, callback);                                                            //
    } else {                                                                                                           //
      callback && callback(new Meteor.Error(404, 'No such file'));                                                     //
    }                                                                                                                  //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FileCursor                                                                                                 //
  @name link                                                                                                           //
  @param version {String} - Name of file's subversion                                                                  //
  @summary Returns downloadable URL to File                                                                            //
  @returns {String}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FileCursor.prototype.link = function (version) {                                                                     //
    if (version == null) {                                                                                             //
      version = 'original';                                                                                            //
    }                                                                                                                  //
    this._collection._debug("[FilesCollection] [FileCursor] [link(" + version + ")]");                                 //
    if (this._fileRef) {                                                                                               //
      return this._collection.link(this._fileRef, version);                                                            //
    } else {                                                                                                           //
      return '';                                                                                                       //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FileCursor                                                                                                 //
  @name get                                                                                                            //
  @param property {String} - Name of sub-object property                                                               //
  @summary Returns current document as a plain Object, if `property` is specified - returns value of sub-object property
  @returns {Object|mix}                                                                                                //
   */                                                                                                                  //
                                                                                                                       //
  FileCursor.prototype.get = function (property) {                                                                     //
    this._collection._debug("[FilesCollection] [FileCursor] [get(" + property + ")]");                                 //
    if (property) {                                                                                                    //
      return this._fileRef[property];                                                                                  //
    } else {                                                                                                           //
      return this._fileRef;                                                                                            //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FileCursor                                                                                                 //
  @name fetch                                                                                                          //
  @summary Returns document as plain Object in Array                                                                   //
  @returns {[Object]}                                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FileCursor.prototype.fetch = function () {                                                                           //
    this._collection._debug('[FilesCollection] [FileCursor] [fetch()]');                                               //
    return [this._fileRef];                                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FileCursor                                                                                                 //
  @name with                                                                                                           //
  @summary Returns reactive version of current FileCursor, useful to use with `{{#with}}...{{/with}}` block template helper
  @returns {[Object]}                                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FileCursor.prototype["with"] = function () {                                                                         //
    var self;                                                                                                          //
    this._collection._debug('[FilesCollection] [FileCursor] [with()]');                                                //
    self = this;                                                                                                       //
    return _.extend(self, this._collection.collection.findOne(this._fileRef._id));                                     //
  };                                                                                                                   //
                                                                                                                       //
  return FileCursor;                                                                                                   //
}());                                                                                                                  //
                                                                                                                       //
/*                                                                                                                     //
@private                                                                                                               //
@locus Anywhere                                                                                                        //
@class FilesCursor                                                                                                     //
@param _selector   {String|Object}   - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)    //
@param options     {Object}          - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#selectors)
@param _collection {FilesCollection} - FilesCollection Instance                                                        //
@summary Implementation of Cursor for FilesCollection                                                                  //
 */                                                                                                                    //
                                                                                                                       //
module.runModuleSetters(FilesCursor = function () {                                                                    //
  function FilesCursor(_selector, options, _collection) {                                                              //
    this._selector = _selector != null ? _selector : {};                                                               //
    this._collection = _collection;                                                                                    //
    this._current = -1;                                                                                                //
    this.cursor = this._collection.collection.find(this._selector, options);                                           //
  }                                                                                                                    //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name get                                                                                                            //
  @summary Returns all matching document(s) as an Array. Alias of `.fetch()`                                           //
  @returns {[Object]}                                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.get = function () {                                                                            //
    this._collection._debug("[FilesCollection] [FilesCursor] [get()]");                                                //
    return this.cursor.fetch();                                                                                        //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name hasNext                                                                                                        //
  @summary Returns `true` if there is next item available on Cursor                                                    //
  @returns {Boolean}                                                                                                   //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.hasNext = function () {                                                                        //
    this._collection._debug('[FilesCollection] [FilesCursor] [hasNext()]');                                            //
    return this._current < this.cursor.count() - 1;                                                                    //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name next                                                                                                           //
  @summary Returns next item on Cursor, if available                                                                   //
  @returns {Object|undefined}                                                                                          //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.next = function () {                                                                           //
    this._collection._debug('[FilesCollection] [FilesCursor] [next()]');                                               //
    if (this.hasNext()) {                                                                                              //
      return this.cursor.fetch()[++this._current];                                                                     //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name hasPrevious                                                                                                    //
  @summary Returns `true` if there is previous item available on Cursor                                                //
  @returns {Boolean}                                                                                                   //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.hasPrevious = function () {                                                                    //
    this._collection._debug('[FilesCollection] [FilesCursor] [hasPrevious()]');                                        //
    return this._current !== -1;                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name previous                                                                                                       //
  @summary Returns previous item on Cursor, if available                                                               //
  @returns {Object|undefined}                                                                                          //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.previous = function () {                                                                       //
    this._collection._debug('[FilesCollection] [FilesCursor] [previous()]');                                           //
    if (this.hasPrevious()) {                                                                                          //
      return this.cursor.fetch()[--this._current];                                                                     //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name fetch                                                                                                          //
  @summary Returns all matching document(s) as an Array.                                                               //
  @returns {[Object]}                                                                                                  //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.fetch = function () {                                                                          //
    this._collection._debug('[FilesCollection] [FilesCursor] [fetch()]');                                              //
    return this.cursor.fetch();                                                                                        //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name first                                                                                                          //
  @summary Returns first item on Cursor, if available                                                                  //
  @returns {Object|undefined}                                                                                          //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.first = function () {                                                                          //
    var ref;                                                                                                           //
    this._collection._debug('[FilesCollection] [FilesCursor] [first()]');                                              //
    this._current = 0;                                                                                                 //
    return (ref = this.fetch()) != null ? ref[this._current] : void 0;                                                 //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name last                                                                                                           //
  @summary Returns last item on Cursor, if available                                                                   //
  @returns {Object|undefined}                                                                                          //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.last = function () {                                                                           //
    var ref;                                                                                                           //
    this._collection._debug('[FilesCollection] [FilesCursor] [last()]');                                               //
    this._current = this.count() - 1;                                                                                  //
    return (ref = this.fetch()) != null ? ref[this._current] : void 0;                                                 //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name count                                                                                                          //
  @summary Returns the number of documents that match a query                                                          //
  @returns {Number}                                                                                                    //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.count = function () {                                                                          //
    this._collection._debug('[FilesCollection] [FilesCursor] [count()]');                                              //
    return this.cursor.count();                                                                                        //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name remove                                                                                                         //
  @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed                  //
  @summary Removes all documents that match a query                                                                    //
  @returns {FilesCursor}                                                                                               //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.remove = function (callback) {                                                                 //
    this._collection._debug('[FilesCollection] [FilesCursor] [remove()]');                                             //
    this._collection.remove(this._selector, callback);                                                                 //
    return this;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name forEach                                                                                                        //
  @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
  @param context {Object} - An object which will be the value of `this` inside `callback`                              //
  @summary Call `callback` once for each matching document, sequentially and synchronously.                            //
  @returns {undefined}                                                                                                 //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.forEach = function (callback, context) {                                                       //
    if (context == null) {                                                                                             //
      context = {};                                                                                                    //
    }                                                                                                                  //
    this._collection._debug('[FilesCollection] [FilesCursor] [forEach()]');                                            //
    this.cursor.forEach(callback, context);                                                                            //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name each                                                                                                           //
  @summary Returns an Array of FileCursor made for each document on current cursor                                     //
           Useful when using in {{#each FilesCursor#each}}...{{/each}} block template helper                           //
  @returns {[FileCursor]}                                                                                              //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.each = function () {                                                                           //
    var self;                                                                                                          //
    self = this;                                                                                                       //
    return this.map(function (file) {                                                                                  //
      return new FileCursor(file, self._collection);                                                                   //
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name map                                                                                                            //
  @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
  @param context {Object} - An object which will be the value of `this` inside `callback`                              //
  @summary Map `callback` over all matching documents. Returns an Array.                                               //
  @returns {Array}                                                                                                     //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.map = function (callback, context) {                                                           //
    if (context == null) {                                                                                             //
      context = {};                                                                                                    //
    }                                                                                                                  //
    this._collection._debug('[FilesCollection] [FilesCursor] [map()]');                                                //
    return this.cursor.map(callback, context);                                                                         //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name current                                                                                                        //
  @summary Returns current item on Cursor, if available                                                                //
  @returns {Object|undefined}                                                                                          //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.current = function () {                                                                        //
    this._collection._debug('[FilesCollection] [FilesCursor] [current()]');                                            //
    if (this._current < 0) {                                                                                           //
      this._current = 0;                                                                                               //
    }                                                                                                                  //
    return this.fetch()[this._current];                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name observe                                                                                                        //
  @param callbacks {Object} - Functions to call to deliver the result set as it changes                                //
  @summary Watch a query. Receive callbacks as the result set changes.                                                 //
  @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observe                                                //
  @returns {Object} - live query handle                                                                                //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.observe = function (callbacks) {                                                               //
    this._collection._debug('[FilesCollection] [FilesCursor] [observe()]');                                            //
    return this.cursor.observe(callbacks);                                                                             //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @locus Anywhere                                                                                                      //
  @memberOf FilesCursor                                                                                                //
  @name observeChanges                                                                                                 //
  @param callbacks {Object} - Functions to call to deliver the result set as it changes                                //
  @summary Watch a query. Receive callbacks as the result set changes. Only the differences between the old and new documents are passed to the callbacks.
  @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observeChanges                                         //
  @returns {Object} - live query handle                                                                                //
   */                                                                                                                  //
                                                                                                                       //
  FilesCursor.prototype.observeChanges = function (callbacks) {                                                        //
    this._collection._debug('[FilesCollection] [FilesCursor] [observeChanges()]');                                     //
    return this.cursor.observeChanges(callbacks);                                                                      //
  };                                                                                                                   //
                                                                                                                       //
  return FilesCursor;                                                                                                  //
}());                                                                                                                  //
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib.coffee":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/lib.coffee                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = require("./lib.coffee.js");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib.coffee.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/lib.coffee.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
module.export({fixJSONParse:function(){return _fixJSONParse},fixJSONStringify:function(){return _fixJSONStringify},formatFleURL:function(){return formatFleURL}});
/*                                                                                                                     //
@var {Function} fixJSONParse - Fix issue with Date parse                                                               //
 */                                                                                                                    //
var _fixJSONParse, _fixJSONStringify, formatFleURL;                                                                    //
                                                                                                                       //
module.runModuleSetters(_fixJSONParse = function fixJSONParse(obj) {                                                   //
  var i, j, key, len, v, value;                                                                                        //
  for (key in meteorBabelHelpers.sanitizeForInObject(obj)) {                                                           //
    value = obj[key];                                                                                                  //
    if (_.isString(value) && !!~value.indexOf('=--JSON-DATE--=')) {                                                    //
      value = value.replace('=--JSON-DATE--=', '');                                                                    //
      obj[key] = new Date(parseInt(value));                                                                            //
    } else if (_.isObject(value)) {                                                                                    //
      obj[key] = _fixJSONParse(value);                                                                                 //
    } else if (_.isArray(value)) {                                                                                     //
      for (i = j = 0, len = value.length; j < len; i = ++j) {                                                          //
        v = value[i];                                                                                                  //
        if (_.isObject(v)) {                                                                                           //
          obj[key][i] = _fixJSONParse(v);                                                                              //
        } else if (_.isString(v) && !!~v.indexOf('=--JSON-DATE--=')) {                                                 //
          v = v.replace('=--JSON-DATE--=', '');                                                                        //
          obj[key][i] = new Date(parseInt(v));                                                                         //
        }                                                                                                              //
      }                                                                                                                //
    }                                                                                                                  //
  }                                                                                                                    //
  return obj;                                                                                                          //
});                                                                                                                    //
                                                                                                                       //
/*                                                                                                                     //
@var {Function} fixJSONStringify - Fix issue with Date stringify                                                       //
 */                                                                                                                    //
                                                                                                                       //
module.runModuleSetters(_fixJSONStringify = function fixJSONStringify(obj) {                                           //
  var i, j, key, len, v, value;                                                                                        //
  for (key in meteorBabelHelpers.sanitizeForInObject(obj)) {                                                           //
    value = obj[key];                                                                                                  //
    if (_.isDate(value)) {                                                                                             //
      obj[key] = '=--JSON-DATE--=' + +value;                                                                           //
    } else if (_.isObject(value)) {                                                                                    //
      obj[key] = _fixJSONStringify(value);                                                                             //
    } else if (_.isArray(value)) {                                                                                     //
      for (i = j = 0, len = value.length; j < len; i = ++j) {                                                          //
        v = value[i];                                                                                                  //
        if (_.isObject(v)) {                                                                                           //
          obj[key][i] = _fixJSONStringify(v);                                                                          //
        } else if (_.isDate(v)) {                                                                                      //
          obj[key][i] = '=--JSON-DATE--=' + +v;                                                                        //
        }                                                                                                              //
      }                                                                                                                //
    }                                                                                                                  //
  }                                                                                                                    //
  return obj;                                                                                                          //
});                                                                                                                    //
                                                                                                                       //
/*                                                                                                                     //
@locus Anywhere                                                                                                        //
@private                                                                                                               //
@name formatFleURL                                                                                                     //
@param {Object} fileRef - File reference object                                                                        //
@param {String} version - [Optional] Version of file you would like build URL for                                      //
@summary Returns formatted URL for file                                                                                //
@returns {String} Downloadable link                                                                                    //
 */                                                                                                                    //
                                                                                                                       //
module.runModuleSetters(formatFleURL = function formatFleURL(fileRef, version) {                                       //
  var ext, ref, root, vRef;                                                                                            //
  if (version == null) {                                                                                               //
    version = 'original';                                                                                              //
  }                                                                                                                    //
  check(fileRef, Object);                                                                                              //
  check(version, String);                                                                                              //
  root = __meteor_runtime_config__.ROOT_URL.replace(/\/+$/, '');                                                       //
  vRef = fileRef.versions && fileRef.versions[version] || fileRef;                                                     //
  if ((ref = vRef.extension) != null ? ref.length : void 0) {                                                          //
    ext = '.' + vRef.extension.replace(/^\./, '');                                                                     //
  } else {                                                                                                             //
    ext = '';                                                                                                          //
  }                                                                                                                    //
  if (fileRef["public"] === true) {                                                                                    //
    return root + (version === 'original' ? fileRef._downloadRoute + "/" + fileRef._id + ext : fileRef._downloadRoute + "/" + version + "-" + fileRef._id + ext);
  } else {                                                                                                             //
    return root + (fileRef._downloadRoute + "/" + fileRef._collectionName + "/" + fileRef._id + "/" + version + "/" + fileRef._id + ext);
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"write-stream.coffee":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/write-stream.coffee                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = require("./write-stream.coffee.js");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"write-stream.coffee.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/write-stream.coffee.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
module.export({writeStream:function(){return writeStream}});var fs;module.import('fs-extra',{"default":function(v){fs=v}});
var NOOP, bound, fdCache, writeStream;                                                                                 //
                                                                                                                       //
NOOP = function NOOP() {};                                                                                             //
                                                                                                                       //
/*                                                                                                                     //
@var {Object} bound - Meteor.bindEnvironment (Fiber wrapper)                                                           //
 */                                                                                                                    //
                                                                                                                       //
bound = Meteor.bindEnvironment(function (callback) {                                                                   //
  return callback();                                                                                                   //
});                                                                                                                    //
                                                                                                                       //
fdCache = {};                                                                                                          //
                                                                                                                       //
/*                                                                                                                     //
@private                                                                                                               //
@locus Server                                                                                                          //
@class writeStream                                                                                                     //
@param path      {String} - Path to file on FS                                                                         //
@param maxLength {Number} - Max amount of chunks in stream                                                             //
@param file      {Object} - fileRef Object                                                                             //
@summary writableStream wrapper class, makes sure chunks is written in given order. Implementation of queue stream.    //
 */                                                                                                                    //
                                                                                                                       //
module.runModuleSetters(writeStream = function () {                                                                    //
  function writeStream(path, maxLength, file, permissions) {                                                           //
    var self;                                                                                                          //
    this.path = path;                                                                                                  //
    this.maxLength = maxLength;                                                                                        //
    this.file = file;                                                                                                  //
    this.permissions = permissions;                                                                                    //
    if (!this.path || !_.isString(this.path)) {                                                                        //
      return;                                                                                                          //
    }                                                                                                                  //
    self = this;                                                                                                       //
    this.fd = null;                                                                                                    //
    this.writtenChunks = 0;                                                                                            //
    this.ended = false;                                                                                                //
    this.aborted = false;                                                                                              //
    if (fdCache[this.path] && !fdCache[this.path].ended && !fdCache[this.path].aborted) {                              //
      this.fd = fdCache[this.path].fd;                                                                                 //
      this.writtenChunks = fdCache[this.path].writtenChunks;                                                           //
    } else {                                                                                                           //
      fs.ensureFile(this.path, function (efError) {                                                                    //
        return bound(function () {                                                                                     //
          if (efError) {                                                                                               //
            throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [Error:]', efError);             //
          } else {                                                                                                     //
            fs.open(self.path, 'r+', self.permissions, function (oError, fd) {                                         //
              return bound(function () {                                                                               //
                if (oError) {                                                                                          //
                  throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [open] [Error:]', oError);
                } else {                                                                                               //
                  self.fd = fd;                                                                                        //
                  fdCache[self.path] = self;                                                                           //
                }                                                                                                      //
              });                                                                                                      //
            });                                                                                                        //
          }                                                                                                            //
        });                                                                                                            //
      });                                                                                                              //
    }                                                                                                                  //
  }                                                                                                                    //
                                                                                                                       //
  /*                                                                                                                   //
  @memberOf writeStream                                                                                                //
  @name write                                                                                                          //
  @param {Number} num - Chunk position in a stream                                                                     //
  @param {Buffer} chunk - Buffer (chunk binary data)                                                                   //
  @param {Function} callback - Callback                                                                                //
  @summary Write chunk in given order                                                                                  //
  @returns {Boolean} - True if chunk is sent to stream, false if chunk is set into queue                               //
   */                                                                                                                  //
                                                                                                                       //
  writeStream.prototype.write = function (num, chunk, callback) {                                                      //
    var self;                                                                                                          //
    if (!this.aborted && !this.ended) {                                                                                //
      self = this;                                                                                                     //
      if (this.fd) {                                                                                                   //
        fs.write(this.fd, chunk, 0, chunk.length, (num - 1) * this.file.chunkSize, function (error, written, buffer) {
          return bound(function () {                                                                                   //
            callback && callback(error, written, buffer);                                                              //
            if (error) {                                                                                               //
              console.warn('[FilesCollection] [writeStream] [write] [Error:]', error);                                 //
              self.abort();                                                                                            //
            } else {                                                                                                   //
              ++self.writtenChunks;                                                                                    //
            }                                                                                                          //
          });                                                                                                          //
        });                                                                                                            //
      } else {                                                                                                         //
        Meteor.setTimeout(function () {                                                                                //
          self.write(num, chunk, callback);                                                                            //
        }, 25);                                                                                                        //
      }                                                                                                                //
    }                                                                                                                  //
    return false;                                                                                                      //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @memberOf writeStream                                                                                                //
  @name end                                                                                                            //
  @param {Function} callback - Callback                                                                                //
  @summary Finishes writing to writableStream, only after all chunks in queue is written                               //
  @returns {Boolean} - True if stream is fulfilled, false if queue is in progress                                      //
   */                                                                                                                  //
                                                                                                                       //
  writeStream.prototype.end = function (callback) {                                                                    //
    var self;                                                                                                          //
    if (!this.aborted && !this.ended) {                                                                                //
      if (this.writtenChunks === this.maxLength) {                                                                     //
        self = this;                                                                                                   //
        fs.close(this.fd, function () {                                                                                //
          return bound(function () {                                                                                   //
            delete fdCache[this.path];                                                                                 //
            self.ended = true;                                                                                         //
            callback && callback(void 0, true);                                                                        //
          });                                                                                                          //
        });                                                                                                            //
        return true;                                                                                                   //
      } else {                                                                                                         //
        self = this;                                                                                                   //
        fs.stat(self.path, function (error, stat) {                                                                    //
          return bound(function () {                                                                                   //
            if (!error && stat) {                                                                                      //
              self.writtenChunks = Math.ceil(stat.size / self.file.chunkSize);                                         //
            }                                                                                                          //
            return Meteor.setTimeout(function () {                                                                     //
              self.end(callback);                                                                                      //
            }, 25);                                                                                                    //
          });                                                                                                          //
        });                                                                                                            //
      }                                                                                                                //
    } else {                                                                                                           //
      callback && callback(void 0, this.ended);                                                                        //
    }                                                                                                                  //
    return false;                                                                                                      //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @memberOf writeStream                                                                                                //
  @name abort                                                                                                          //
  @param {Function} callback - Callback                                                                                //
  @summary Aborts writing to writableStream, removes created file                                                      //
  @returns {Boolean} - True                                                                                            //
   */                                                                                                                  //
                                                                                                                       //
  writeStream.prototype.abort = function (callback) {                                                                  //
    this.aborted = true;                                                                                               //
    delete fdCache[this.path];                                                                                         //
    fs.unlink(this.path, callback || NOOP);                                                                            //
    return true;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  /*                                                                                                                   //
  @memberOf writeStream                                                                                                //
  @name stop                                                                                                           //
  @summary Stop writing to writableStream                                                                              //
  @returns {Boolean} - True                                                                                            //
   */                                                                                                                  //
                                                                                                                       //
  writeStream.prototype.stop = function () {                                                                           //
    this.aborted = true;                                                                                               //
    delete fdCache[this.path];                                                                                         //
    return true;                                                                                                       //
  };                                                                                                                   //
                                                                                                                       //
  return writeStream;                                                                                                  //
}());                                                                                                                  //
                                                                                                                       //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"fs-extra":{"package.json":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// ../../.1.8.3.e0v2ee++os+web.browser+web.cordova/npm/node_modules/fs-extra/package.json                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
exports.name = "fs-extra";
exports.version = "4.0.1";
exports.main = "./lib/index";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/fs-extra/lib/index.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict'

const assign = require('./util/assign')

const fs = {}

// Export graceful-fs:
assign(fs, require('./fs'))
// Export extra methods:
assign(fs, require('./copy'))
assign(fs, require('./copy-sync'))
assign(fs, require('./mkdirs'))
assign(fs, require('./remove'))
assign(fs, require('./json'))
assign(fs, require('./move'))
assign(fs, require('./move-sync'))
assign(fs, require('./empty'))
assign(fs, require('./ensure'))
assign(fs, require('./output'))
assign(fs, require('./path-exists'))

module.exports = fs

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"request":{"package.json":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// ../../.1.8.3.e0v2ee++os+web.browser+web.cordova/npm/node_modules/request/package.json                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
exports.name = "request";
exports.version = "2.81.0";
exports.main = "index.js";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/request/index.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Copyright 2010-2012 Mikeal Rogers
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

'use strict'

var extend                = require('extend')
  , cookies               = require('./lib/cookies')
  , helpers               = require('./lib/helpers')

var paramsHaveRequestBody = helpers.paramsHaveRequestBody


// organize params for patch, post, put, head, del
function initParams(uri, options, callback) {
  if (typeof options === 'function') {
    callback = options
  }

  var params = {}
  if (typeof options === 'object') {
    extend(params, options, {uri: uri})
  } else if (typeof uri === 'string') {
    extend(params, {uri: uri})
  } else {
    extend(params, uri)
  }

  params.callback = callback || params.callback
  return params
}

function request (uri, options, callback) {
  if (typeof uri === 'undefined') {
    throw new Error('undefined is not a valid uri or options object.')
  }

  var params = initParams(uri, options, callback)

  if (params.method === 'HEAD' && paramsHaveRequestBody(params)) {
    throw new Error('HTTP HEAD requests MUST NOT include a request body.')
  }

  return new request.Request(params)
}

function verbFunc (verb) {
  var method = verb.toUpperCase()
  return function (uri, options, callback) {
    var params = initParams(uri, options, callback)
    params.method = method
    return request(params, params.callback)
  }
}

// define like this to please codeintel/intellisense IDEs
request.get = verbFunc('get')
request.head = verbFunc('head')
request.post = verbFunc('post')
request.put = verbFunc('put')
request.patch = verbFunc('patch')
request.del = verbFunc('delete')
request['delete'] = verbFunc('delete')

request.jar = function (store) {
  return cookies.jar(store)
}

request.cookie = function (str) {
  return cookies.parse(str)
}

function wrapRequestMethod (method, options, requester, verb) {

  return function (uri, opts, callback) {
    var params = initParams(uri, opts, callback)

    var target = {}
    extend(true, target, options, params)

    target.pool = params.pool || options.pool

    if (verb) {
      target.method = verb.toUpperCase()
    }

    if (typeof requester === 'function') {
      method = requester
    }

    return method(target, target.callback)
  }
}

request.defaults = function (options, requester) {
  var self = this

  options = options || {}

  if (typeof options === 'function') {
    requester = options
    options = {}
  }

  var defaults      = wrapRequestMethod(self, options, requester)

  var verbs = ['get', 'head', 'post', 'put', 'patch', 'del', 'delete']
  verbs.forEach(function(verb) {
    defaults[verb]  = wrapRequestMethod(self[verb], options, requester, verb)
  })

  defaults.cookie   = wrapRequestMethod(self.cookie, options, requester)
  defaults.jar      = self.jar
  defaults.defaults = self.defaults
  return defaults
}

request.forever = function (agentOptions, optionsArg) {
  var options = {}
  if (optionsArg) {
    extend(options, optionsArg)
  }
  if (agentOptions) {
    options.agentOptions = agentOptions
  }

  options.forever = true
  return request.defaults(options)
}

// Exports

module.exports = request
request.Request = require('./request')
request.initParams = initParams

// Backwards compatibility for request.debug
Object.defineProperty(request, 'debug', {
  enumerable : true,
  get : function() {
    return request.Request.debug
  },
  set : function(debug) {
    request.Request.debug = debug
  }
})

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"throttle":{"package.json":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// ../../.1.8.3.e0v2ee++os+web.browser+web.cordova/npm/node_modules/throttle/package.json                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
exports.name = "throttle";
exports.version = "1.0.3";
exports.main = "./throttle";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"throttle.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/throttle/throttle.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //

/**
 * Module dependencies.
 */

var assert = require('assert');
var Parser = require('stream-parser');
var inherits = require('util').inherits;
var Transform = require('stream').Transform;

// node v0.8.x compat
if (!Transform) Transform = require('readable-stream/transform');

/**
 * Module exports.
 */

module.exports = Throttle;

/**
 * The `Throttle` passthrough stream class is very similar to the node core
 * `stream.Passthrough` stream, except that you specify a `bps` "bytes per
 * second" option and data *will not* be passed through faster than the byte
 * value you specify.
 *
 * You can invoke with just a `bps` Number and get the rest of the default
 * options. This should be more common:
 *
 * ``` js
 * process.stdin.pipe(new Throttle(100 * 1024)).pipe(process.stdout);
 * ```
 *
 * Or you can pass an `options` Object in, with a `bps` value specified along with
 * other options:
 *
 * ``` js
 * var t = new Throttle({ bps: 100 * 1024, chunkSize: 100, highWaterMark: 500 });
 * ```
 *
 * @param {Number|Object} opts an options object or the "bps" Number value
 * @api public
 */

function Throttle (opts) {
  if (!(this instanceof Throttle)) return new Throttle(opts);

  if ('number' == typeof opts) opts = { bps: opts };
  if (!opts) opts = {};
  if (null == opts.lowWaterMark) opts.lowWaterMark = 0;
  if (null == opts.highWaterMark) opts.highWaterMark = 0;
  if (null == opts.bps) throw new Error('must pass a "bps" bytes-per-second option');
  if (null == opts.chunkSize) opts.chunkSize = opts.bps / 10 | 0; // 1/10th of "bps" by default

  Transform.call(this, opts);

  this.bps = opts.bps;
  this.chunkSize = Math.max(1, opts.chunkSize);

  this.totalBytes = 0;
  this.startTime = Date.now();

  this._passthroughChunk();
}
inherits(Throttle, Transform);

/**
 * Mixin `Parser`.
 */

Parser(Throttle.prototype);

/**
 * Begins passing through the next "chunk" of bytes.
 *
 * @api private
 */

Throttle.prototype._passthroughChunk = function () {
  this._passthrough(this.chunkSize, this._onchunk);
  this.totalBytes += this.chunkSize;
};

/**
 * Called once a "chunk" of bytes has been passed through. Waits if necessary
 * before passing through the next chunk of bytes.
 *
 * @api private
 */

Throttle.prototype._onchunk = function (output, done) {
  var self = this;
  var totalSeconds = (Date.now() - this.startTime) / 1000;
  var expected = totalSeconds * this.bps;

  function d () {
    self._passthroughChunk();
    done();
  }

  if (this.totalBytes > expected) {
    // Use this byte count to calculate how many seconds ahead we are.
    var remainder = this.totalBytes - expected;
    var sleepTime = remainder / this.bps * 1000;
    //console.error('sleep time: %d', sleepTime);
    if (sleepTime > 0) {
      setTimeout(d, sleepTime);
    } else {
      d();
    }
  } else {
    d();
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"file-type":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/file-type/index.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict';
const toBytes = s => Array.from(s).map(c => c.charCodeAt(0));
const xpiZipFilename = toBytes('META-INF/mozilla.rsa');
const oxmlContentTypes = toBytes('[Content_Types].xml');
const oxmlRels = toBytes('_rels/.rels');

module.exports = input => {
	const buf = new Uint8Array(input);

	if (!(buf && buf.length > 1)) {
		return null;
	}

	const check = (header, opts) => {
		opts = Object.assign({
			offset: 0
		}, opts);

		for (let i = 0; i < header.length; i++) {
			if (header[i] !== buf[i + opts.offset]) {
				return false;
			}
		}

		return true;
	};

	if (check([0xFF, 0xD8, 0xFF])) {
		return {
			ext: 'jpg',
			mime: 'image/jpeg'
		};
	}

	if (check([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])) {
		return {
			ext: 'png',
			mime: 'image/png'
		};
	}

	if (check([0x47, 0x49, 0x46])) {
		return {
			ext: 'gif',
			mime: 'image/gif'
		};
	}

	if (check([0x57, 0x45, 0x42, 0x50], {offset: 8})) {
		return {
			ext: 'webp',
			mime: 'image/webp'
		};
	}

	if (check([0x46, 0x4C, 0x49, 0x46])) {
		return {
			ext: 'flif',
			mime: 'image/flif'
		};
	}

	// Needs to be before `tif` check
	if (
		(check([0x49, 0x49, 0x2A, 0x0]) || check([0x4D, 0x4D, 0x0, 0x2A])) &&
		check([0x43, 0x52], {offset: 8})
	) {
		return {
			ext: 'cr2',
			mime: 'image/x-canon-cr2'
		};
	}

	if (
		check([0x49, 0x49, 0x2A, 0x0]) ||
		check([0x4D, 0x4D, 0x0, 0x2A])
	) {
		return {
			ext: 'tif',
			mime: 'image/tiff'
		};
	}

	if (check([0x42, 0x4D])) {
		return {
			ext: 'bmp',
			mime: 'image/bmp'
		};
	}

	if (check([0x49, 0x49, 0xBC])) {
		return {
			ext: 'jxr',
			mime: 'image/vnd.ms-photo'
		};
	}

	if (check([0x38, 0x42, 0x50, 0x53])) {
		return {
			ext: 'psd',
			mime: 'image/vnd.adobe.photoshop'
		};
	}

	// Zip-based file formats
	// Need to be before the `zip` check
	if (check([0x50, 0x4B, 0x3, 0x4])) {
		if (
			check([0x6D, 0x69, 0x6D, 0x65, 0x74, 0x79, 0x70, 0x65, 0x61, 0x70, 0x70, 0x6C, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6F, 0x6E, 0x2F, 0x65, 0x70, 0x75, 0x62, 0x2B, 0x7A, 0x69, 0x70], {offset: 30})
		) {
			return {
				ext: 'epub',
				mime: 'application/epub+zip'
			};
		}

		// Assumes signed `.xpi` from addons.mozilla.org
		if (check(xpiZipFilename, {offset: 30})) {
			return {
				ext: 'xpi',
				mime: 'application/x-xpinstall'
			};
		}

		// https://github.com/file/file/blob/master/magic/Magdir/msooxml
		if (check(oxmlContentTypes, {offset: 30}) || check(oxmlRels, {offset: 30})) {
			const sliced = buf.subarray(4, 4 + 2000);
			const nextZipHeaderIndex = arr => arr.findIndex((el, i, arr) => arr[i] === 0x50 && arr[i + 1] === 0x4B && arr[i + 2] === 0x3 && arr[i + 3] === 0x4);
			const header2Pos = nextZipHeaderIndex(sliced);

			if (header2Pos !== -1) {
				const slicedAgain = buf.subarray(header2Pos + 8, header2Pos + 8 + 1000);
				const header3Pos = nextZipHeaderIndex(slicedAgain);

				if (header3Pos !== -1) {
					const offset = 8 + header2Pos + header3Pos + 30;

					if (check(toBytes('word/'), {offset})) {
						return {
							ext: 'docx',
							mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
						};
					}

					if (check(toBytes('ppt/'), {offset})) {
						return {
							ext: 'pptx',
							mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
						};
					}

					if (check(toBytes('xl/'), {offset})) {
						return {
							ext: 'xlsx',
							mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
						};
					}
				}
			}
		}
	}

	if (
		check([0x50, 0x4B]) &&
		(buf[2] === 0x3 || buf[2] === 0x5 || buf[2] === 0x7) &&
		(buf[3] === 0x4 || buf[3] === 0x6 || buf[3] === 0x8)
	) {
		return {
			ext: 'zip',
			mime: 'application/zip'
		};
	}

	if (check([0x75, 0x73, 0x74, 0x61, 0x72], {offset: 257})) {
		return {
			ext: 'tar',
			mime: 'application/x-tar'
		};
	}

	if (
		check([0x52, 0x61, 0x72, 0x21, 0x1A, 0x7]) &&
		(buf[6] === 0x0 || buf[6] === 0x1)
	) {
		return {
			ext: 'rar',
			mime: 'application/x-rar-compressed'
		};
	}

	if (check([0x1F, 0x8B, 0x8])) {
		return {
			ext: 'gz',
			mime: 'application/gzip'
		};
	}

	if (check([0x42, 0x5A, 0x68])) {
		return {
			ext: 'bz2',
			mime: 'application/x-bzip2'
		};
	}

	if (check([0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C])) {
		return {
			ext: '7z',
			mime: 'application/x-7z-compressed'
		};
	}

	if (check([0x78, 0x01])) {
		return {
			ext: 'dmg',
			mime: 'application/x-apple-diskimage'
		};
	}

	if (check([0x33, 0x67, 0x70, 0x35]) || // 3gp5
		(
			check([0x0, 0x0, 0x0]) && check([0x66, 0x74, 0x79, 0x70], {offset: 4}) &&
				(
					check([0x6D, 0x70, 0x34, 0x31], {offset: 8}) || // MP41
					check([0x6D, 0x70, 0x34, 0x32], {offset: 8}) || // MP42
					check([0x69, 0x73, 0x6F, 0x6D], {offset: 8}) || // ISOM
					check([0x69, 0x73, 0x6F, 0x32], {offset: 8}) || // ISO2
					check([0x6D, 0x6D, 0x70, 0x34], {offset: 8}) || // MMP4
					check([0x4D, 0x34, 0x56], {offset: 8}) || // M4V
					check([0x64, 0x61, 0x73, 0x68], {offset: 8}) // DASH
				)
		)) {
		return {
			ext: 'mp4',
			mime: 'video/mp4'
		};
	}

	if (check([0x4D, 0x54, 0x68, 0x64])) {
		return {
			ext: 'mid',
			mime: 'audio/midi'
		};
	}

	// https://github.com/threatstack/libmagic/blob/master/magic/Magdir/matroska
	if (check([0x1A, 0x45, 0xDF, 0xA3])) {
		const sliced = buf.subarray(4, 4 + 4096);
		const idPos = sliced.findIndex((el, i, arr) => arr[i] === 0x42 && arr[i + 1] === 0x82);

		if (idPos !== -1) {
			const docTypePos = idPos + 3;
			const findDocType = type => Array.from(type).every((c, i) => sliced[docTypePos + i] === c.charCodeAt(0));

			if (findDocType('matroska')) {
				return {
					ext: 'mkv',
					mime: 'video/x-matroska'
				};
			}

			if (findDocType('webm')) {
				return {
					ext: 'webm',
					mime: 'video/webm'
				};
			}
		}
	}

	if (check([0x0, 0x0, 0x0, 0x14, 0x66, 0x74, 0x79, 0x70, 0x71, 0x74, 0x20, 0x20]) ||
		check([0x66, 0x72, 0x65, 0x65], {offset: 4}) ||
		check([0x66, 0x74, 0x79, 0x70, 0x71, 0x74, 0x20, 0x20], {offset: 4}) ||
		check([0x6D, 0x64, 0x61, 0x74], {offset: 4}) || // MJPEG
		check([0x77, 0x69, 0x64, 0x65], {offset: 4})) {
		return {
			ext: 'mov',
			mime: 'video/quicktime'
		};
	}

	if (
		check([0x52, 0x49, 0x46, 0x46]) &&
		check([0x41, 0x56, 0x49], {offset: 8})
	) {
		return {
			ext: 'avi',
			mime: 'video/x-msvideo'
		};
	}

	if (check([0x30, 0x26, 0xB2, 0x75, 0x8E, 0x66, 0xCF, 0x11, 0xA6, 0xD9])) {
		return {
			ext: 'wmv',
			mime: 'video/x-ms-wmv'
		};
	}

	if (check([0x0, 0x0, 0x1, 0xBA])) {
		return {
			ext: 'mpg',
			mime: 'video/mpeg'
		};
	}

	if (
		check([0x49, 0x44, 0x33]) ||
		check([0xFF, 0xFB])
	) {
		return {
			ext: 'mp3',
			mime: 'audio/mpeg'
		};
	}

	if (
		check([0x66, 0x74, 0x79, 0x70, 0x4D, 0x34, 0x41], {offset: 4}) ||
		check([0x4D, 0x34, 0x41, 0x20])
	) {
		return {
			ext: 'm4a',
			mime: 'audio/m4a'
		};
	}

	// Needs to be before `ogg` check
	if (check([0x4F, 0x70, 0x75, 0x73, 0x48, 0x65, 0x61, 0x64], {offset: 28})) {
		return {
			ext: 'opus',
			mime: 'audio/opus'
		};
	}

	if (check([0x4F, 0x67, 0x67, 0x53])) {
		return {
			ext: 'ogg',
			mime: 'audio/ogg'
		};
	}

	if (check([0x66, 0x4C, 0x61, 0x43])) {
		return {
			ext: 'flac',
			mime: 'audio/x-flac'
		};
	}

	if (
		check([0x52, 0x49, 0x46, 0x46]) &&
		check([0x57, 0x41, 0x56, 0x45], {offset: 8})
	) {
		return {
			ext: 'wav',
			mime: 'audio/x-wav'
		};
	}

	if (check([0x23, 0x21, 0x41, 0x4D, 0x52, 0x0A])) {
		return {
			ext: 'amr',
			mime: 'audio/amr'
		};
	}

	if (check([0x25, 0x50, 0x44, 0x46])) {
		return {
			ext: 'pdf',
			mime: 'application/pdf'
		};
	}

	if (check([0x4D, 0x5A])) {
		return {
			ext: 'exe',
			mime: 'application/x-msdownload'
		};
	}

	if (
		(buf[0] === 0x43 || buf[0] === 0x46) &&
		check([0x57, 0x53], {offset: 1})
	) {
		return {
			ext: 'swf',
			mime: 'application/x-shockwave-flash'
		};
	}

	if (check([0x7B, 0x5C, 0x72, 0x74, 0x66])) {
		return {
			ext: 'rtf',
			mime: 'application/rtf'
		};
	}

	if (check([0x00, 0x61, 0x73, 0x6D])) {
		return {
			ext: 'wasm',
			mime: 'application/wasm'
		};
	}

	if (
		check([0x77, 0x4F, 0x46, 0x46]) &&
		(
			check([0x00, 0x01, 0x00, 0x00], {offset: 4}) ||
			check([0x4F, 0x54, 0x54, 0x4F], {offset: 4})
		)
	) {
		return {
			ext: 'woff',
			mime: 'font/woff'
		};
	}

	if (
		check([0x77, 0x4F, 0x46, 0x32]) &&
		(
			check([0x00, 0x01, 0x00, 0x00], {offset: 4}) ||
			check([0x4F, 0x54, 0x54, 0x4F], {offset: 4})
		)
	) {
		return {
			ext: 'woff2',
			mime: 'font/woff2'
		};
	}

	if (
		check([0x4C, 0x50], {offset: 34}) &&
		(
			check([0x00, 0x00, 0x01], {offset: 8}) ||
			check([0x01, 0x00, 0x02], {offset: 8}) ||
			check([0x02, 0x00, 0x02], {offset: 8})
		)
	) {
		return {
			ext: 'eot',
			mime: 'application/octet-stream'
		};
	}

	if (check([0x00, 0x01, 0x00, 0x00, 0x00])) {
		return {
			ext: 'ttf',
			mime: 'font/ttf'
		};
	}

	if (check([0x4F, 0x54, 0x54, 0x4F, 0x00])) {
		return {
			ext: 'otf',
			mime: 'font/otf'
		};
	}

	if (check([0x00, 0x00, 0x01, 0x00])) {
		return {
			ext: 'ico',
			mime: 'image/x-icon'
		};
	}

	if (check([0x46, 0x4C, 0x56, 0x01])) {
		return {
			ext: 'flv',
			mime: 'video/x-flv'
		};
	}

	if (check([0x25, 0x21])) {
		return {
			ext: 'ps',
			mime: 'application/postscript'
		};
	}

	if (check([0xFD, 0x37, 0x7A, 0x58, 0x5A, 0x00])) {
		return {
			ext: 'xz',
			mime: 'application/x-xz'
		};
	}

	if (check([0x53, 0x51, 0x4C, 0x69])) {
		return {
			ext: 'sqlite',
			mime: 'application/x-sqlite3'
		};
	}

	if (check([0x4E, 0x45, 0x53, 0x1A])) {
		return {
			ext: 'nes',
			mime: 'application/x-nintendo-nes-rom'
		};
	}

	if (check([0x43, 0x72, 0x32, 0x34])) {
		return {
			ext: 'crx',
			mime: 'application/x-google-chrome-extension'
		};
	}

	if (
		check([0x4D, 0x53, 0x43, 0x46]) ||
		check([0x49, 0x53, 0x63, 0x28])
	) {
		return {
			ext: 'cab',
			mime: 'application/vnd.ms-cab-compressed'
		};
	}

	// Needs to be before `ar` check
	if (check([0x21, 0x3C, 0x61, 0x72, 0x63, 0x68, 0x3E, 0x0A, 0x64, 0x65, 0x62, 0x69, 0x61, 0x6E, 0x2D, 0x62, 0x69, 0x6E, 0x61, 0x72, 0x79])) {
		return {
			ext: 'deb',
			mime: 'application/x-deb'
		};
	}

	if (check([0x21, 0x3C, 0x61, 0x72, 0x63, 0x68, 0x3E])) {
		return {
			ext: 'ar',
			mime: 'application/x-unix-archive'
		};
	}

	if (check([0xED, 0xAB, 0xEE, 0xDB])) {
		return {
			ext: 'rpm',
			mime: 'application/x-rpm'
		};
	}

	if (
		check([0x1F, 0xA0]) ||
		check([0x1F, 0x9D])
	) {
		return {
			ext: 'Z',
			mime: 'application/x-compress'
		};
	}

	if (check([0x4C, 0x5A, 0x49, 0x50])) {
		return {
			ext: 'lz',
			mime: 'application/x-lzip'
		};
	}

	if (check([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1])) {
		return {
			ext: 'msi',
			mime: 'application/x-msi'
		};
	}

	if (check([0x06, 0x0E, 0x2B, 0x34, 0x02, 0x05, 0x01, 0x01, 0x0D, 0x01, 0x02, 0x01, 0x01, 0x02])) {
		return {
			ext: 'mxf',
			mime: 'application/mxf'
		};
	}

	if (check([0x47], {offset: 4}) && (check([0x47], {offset: 192}) || check([0x47], {offset: 196}))) {
		return {
			ext: 'mts',
			mime: 'video/mp2t'
		};
	}

	if (check([0x42, 0x4C, 0x45, 0x4E, 0x44, 0x45, 0x52])) {
		return {
			ext: 'blend',
			mime: 'application/x-blender'
		};
	}

	if (check([0x42, 0x50, 0x47, 0xFB])) {
		return {
			ext: 'bpg',
			mime: 'image/bpg'
		};
	}

	return null;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json",
    ".coffee",
    ".jsx"
  ]
});
var exports = require("./node_modules/meteor/ostrio:files/server.coffee.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['ostrio:files'] = exports, {
  FilesCollection: FilesCollection
});

})();

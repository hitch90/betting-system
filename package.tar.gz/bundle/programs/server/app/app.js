var require = meteorInstall({"imports":{"api":{"bets.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/bets.js                                                                                    //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({                                                                                           // 1
  Bets: function () {                                                                                     // 1
    return Bets;                                                                                          // 1
  }                                                                                                       // 1
});                                                                                                       // 1
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
var Matches = void 0;                                                                                     // 1
module.watch(require("./matches.js"), {                                                                   // 1
  Matches: function (v) {                                                                                 // 1
    Matches = v;                                                                                          // 1
  }                                                                                                       // 1
}, 3);                                                                                                    // 1
var Bets = new Mongo.Collection('bets');                                                                  // 5
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 7
  // This code only runs on the server                                                                    // 8
  Meteor.publish('bets.all', function () {                                                                // 9
    function MatchesPublication() {                                                                       // 9
      return Bets.find();                                                                                 // 10
    }                                                                                                     // 11
                                                                                                          //
    return MatchesPublication;                                                                            // 9
  }());                                                                                                   // 9
}                                                                                                         // 12
                                                                                                          //
Meteor.methods({                                                                                          // 14
  'bets.insert': function (userId, userchoice, stake, matchId) {                                          // 15
    // Make sure the user is logged in before inserting a task                                            // 16
    if (!Meteor.userId()) {                                                                               // 17
      throw new Meteor.Error('not-authorized');                                                           // 18
    }                                                                                                     // 19
                                                                                                          //
    check(stake, String);                                                                                 // 20
    check(userchoice, String);                                                                            // 21
    check(matchId, String);                                                                               // 22
    check(userId, String);                                                                                // 23
    var userHasBetInMatch = Bets.find({                                                                   // 24
      $and: [{                                                                                            // 25
        userId: userId                                                                                    // 25
      }, {                                                                                                // 25
        userchoice: userchoice                                                                            // 25
      }, {                                                                                                // 25
        matchId: matchId                                                                                  // 25
      }]                                                                                                  // 25
    }).count();                                                                                           // 24
                                                                                                          //
    if (userHasBetInMatch == 1) {                                                                         // 27
      var userBet = Bets.findOne({                                                                        // 28
        $and: [{                                                                                          // 29
          userId: userId                                                                                  // 29
        }, {                                                                                              // 29
          userchoice: userchoice                                                                          // 29
        }, {                                                                                              // 29
          matchId: matchId                                                                                // 29
        }]                                                                                                // 29
      });                                                                                                 // 28
      var newStake = parseInt(userBet.stake) + parseInt(stake);                                           // 31
      Bets.update({                                                                                       // 32
        $and: [{                                                                                          // 34
          userId: userId                                                                                  // 34
        }, {                                                                                              // 34
          userchoice: userchoice                                                                          // 34
        }, {                                                                                              // 34
          matchId: matchId                                                                                // 34
        }]                                                                                                // 34
      }, {                                                                                                // 33
        $set: {                                                                                           // 37
          stake: newStake                                                                                 // 37
        }                                                                                                 // 37
      });                                                                                                 // 36
    } else {                                                                                              // 40
      Bets.insert({                                                                                       // 41
        userId: userId,                                                                                   // 42
        userchoice: userchoice,                                                                           // 43
        stake: stake,                                                                                     // 44
        matchId: matchId,                                                                                 // 45
        complete: false                                                                                   // 46
      });                                                                                                 // 41
    }                                                                                                     // 48
  },                                                                                                      // 49
  'bets.finish': function (matchId) {                                                                     // 50
    if (!Meteor.userId()) {                                                                               // 51
      throw new Meteor.Error('not-authorized');                                                           // 52
    }                                                                                                     // 53
                                                                                                          //
    var bets = Bets.find({                                                                                // 54
      matchId: matchId                                                                                    // 54
    }).fetch();                                                                                           // 54
    var match = Matches.findOne({                                                                         // 55
      _id: matchId                                                                                        // 55
    });                                                                                                   // 55
                                                                                                          //
    if (match.winner !== 'x') {                                                                           // 56
      var stake = 0,                                                                                      // 57
          percentAll = 0,                                                                                 // 57
          restPercent = 0,                                                                                // 57
          perUserAdd = 0,                                                                                 // 57
          restOfStake = 0;                                                                                // 57
      var winningBets = [];                                                                               // 62
                                                                                                          //
      for (var i in meteorBabelHelpers.sanitizeForInObject(bets)) {                                       // 63
        var bet = bets[i];                                                                                // 64
        stake = parseInt(stake) + parseInt(bet.stake);                                                    // 65
        Bets.update({                                                                                     // 66
          _id: bet._id                                                                                    // 66
        }, {                                                                                              // 66
          $set: {                                                                                         // 66
            complete: true                                                                                // 66
          }                                                                                               // 66
        });                                                                                               // 66
                                                                                                          //
        if (bet.userchoice === match.winner) {                                                            // 67
          winningBets.push(bet);                                                                          // 68
        }                                                                                                 // 69
      }                                                                                                   // 70
                                                                                                          //
      restOfStake = stake;                                                                                // 71
                                                                                                          //
      for (var _i in meteorBabelHelpers.sanitizeForInObject(winningBets)) {                               // 72
        var _bet = winningBets[_i];                                                                       // 73
        var currentUserTokens = Meteor.users.findOne({                                                    // 74
          _id: _bet.userId                                                                                // 75
        }, {                                                                                              // 75
          fields: {                                                                                       // 76
            'profile.tokens': 1                                                                           // 76
          }                                                                                               // 76
        });                                                                                               // 76
        percent = Math.floor(parseInt(_bet.stake) / stake * 100);                                         // 78
        _bet.percent = parseInt(percent);                                                                 // 79
        _bet.userTokens = currentUserTokens;                                                              // 80
        _bet.userTokens.profile.tokens = parseInt(_bet.userTokens.profile.tokens) + parseInt(_bet.stake);
        restOfStake = restOfStake - parseInt(_bet.stake);                                                 // 83
        percentAll = percentAll + percent;                                                                // 84
      }                                                                                                   // 85
                                                                                                          //
      restPercent = 100 - percentAll;                                                                     // 86
      perUserAdd = restPercent / winningBets.length;                                                      // 87
                                                                                                          //
      for (var _i2 in meteorBabelHelpers.sanitizeForInObject(winningBets)) {                              // 88
        var _bet2 = winningBets[_i2];                                                                     // 89
        _bet2.percent = parseInt(_bet2.percent) + perUserAdd;                                             // 90
        var toAdd = restOfStake * parseInt(_bet2.percent) / 100;                                          // 91
        var tokens = parseInt(_bet2.userTokens.profile.tokens) + toAdd;                                   // 92
        Meteor.users.update(_bet2.userTokens._id, {                                                       // 93
          $set: {                                                                                         // 94
            'profile.tokens': tokens                                                                      // 94
          }                                                                                               // 94
        });                                                                                               // 93
      }                                                                                                   // 96
    }                                                                                                     // 97
  }                                                                                                       // 98
});                                                                                                       // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"events.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/events.js                                                                                  //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({                                                                                           // 1
  Events: function () {                                                                                   // 1
    return Events;                                                                                        // 1
  }                                                                                                       // 1
});                                                                                                       // 1
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
var Events = new Mongo.Collection('events');                                                              // 4
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 6
  // This code only runs on the server                                                                    // 7
  Meteor.publish('events.all', function () {                                                              // 8
    function MatchesPublication() {                                                                       // 8
      return Events.find();                                                                               // 9
    }                                                                                                     // 10
                                                                                                          //
    return MatchesPublication;                                                                            // 8
  }());                                                                                                   // 8
}                                                                                                         // 11
                                                                                                          //
Meteor.methods({                                                                                          // 13
  'events.insert': function (name, slug, logo, image) {                                                   // 14
    if (!Meteor.userId()) {                                                                               // 15
      throw new Meteor.Error('not-authorized');                                                           // 16
    }                                                                                                     // 17
                                                                                                          //
    Events.insert({                                                                                       // 18
      name: name,                                                                                         // 19
      slug: slug,                                                                                         // 20
      logo: logo,                                                                                         // 21
      image: image                                                                                        // 22
    });                                                                                                   // 18
  },                                                                                                      // 24
  'events.remove': function (id) {                                                                        // 25
    Events.remove(id);                                                                                    // 26
  }                                                                                                       // 27
});                                                                                                       // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"games.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/games.js                                                                                   //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({                                                                                           // 1
  Games: function () {                                                                                    // 1
    return Games;                                                                                         // 1
  }                                                                                                       // 1
});                                                                                                       // 1
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
var Games = new Mongo.Collection('games');                                                                // 4
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 6
  // This code only runs on the server                                                                    // 7
  Meteor.publish('games.all', function () {                                                               // 8
    function MatchesPublication() {                                                                       // 8
      return Games.find();                                                                                // 9
    }                                                                                                     // 10
                                                                                                          //
    return MatchesPublication;                                                                            // 8
  }());                                                                                                   // 8
}                                                                                                         // 11
                                                                                                          //
Meteor.methods({                                                                                          // 13
  'games.insert': function (name, slug, logo, image) {                                                    // 14
    // Make sure the user is logged in before inserting a task                                            // 15
    if (!Meteor.userId()) {                                                                               // 16
      throw new Meteor.Error('not-authorized');                                                           // 17
    }                                                                                                     // 18
                                                                                                          //
    Games.insert({                                                                                        // 20
      name: name,                                                                                         // 21
      slug: slug,                                                                                         // 22
      logo: logo,                                                                                         // 23
      image: image                                                                                        // 24
    });                                                                                                   // 20
  },                                                                                                      // 26
  'games.remove': function (id) {                                                                         // 27
    Games.remove(id);                                                                                     // 28
  } //   "teams.setChecked"(taskId, setChecked) {                                                         // 29
  //     check(taskId, String);                                                                           // 31
  //     check(setChecked, Boolean);                                                                      // 32
  //     Teams.update(taskId, { $set: { checked: setChecked } });                                         // 34
  //   }                                                                                                  // 35
                                                                                                          //
});                                                                                                       // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"images.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/images.js                                                                                  //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"matches.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/matches.js                                                                                 //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({                                                                                           // 1
  Matches: function () {                                                                                  // 1
    return Matches;                                                                                       // 1
  }                                                                                                       // 1
});                                                                                                       // 1
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
var Teams = void 0;                                                                                       // 1
module.watch(require("./teams"), {                                                                        // 1
  Teams: function (v) {                                                                                   // 1
    Teams = v;                                                                                            // 1
  }                                                                                                       // 1
}, 3);                                                                                                    // 1
var Matches = new Mongo.Collection('matches');                                                            // 5
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 7
  // This code only runs on the server                                                                    // 8
  Meteor.publish('matches.all', function () {                                                             // 9
    function MatchesPublication() {                                                                       // 9
      return Matches.find();                                                                              // 10
    }                                                                                                     // 11
                                                                                                          //
    return MatchesPublication;                                                                            // 9
  }());                                                                                                   // 9
  Meteor.publish('matches.one', function () {                                                             // 12
    function showMatch(id) {                                                                              // 12
      console.log(id);                                                                                    // 13
      return Matches.find({                                                                               // 14
        _id: id                                                                                           // 14
      });                                                                                                 // 14
    }                                                                                                     // 15
                                                                                                          //
    return showMatch;                                                                                     // 12
  }());                                                                                                   // 12
}                                                                                                         // 16
                                                                                                          //
Meteor.methods({                                                                                          // 18
  'matches.insert': function (firstOpponent, secondOpponent, game, event, startAt) {                      // 19
    var winner = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : '';                  // 28
    var complete = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;             // 28
    var canceled = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : false;             // 28
                                                                                                          //
    // Make sure the user is logged in before inserting a task                                            // 29
    if (!Meteor.userId()) {                                                                               // 30
      throw new Meteor.Error('not-authorized');                                                           // 31
    }                                                                                                     // 32
                                                                                                          //
    Matches.insert({                                                                                      // 34
      firstOpponent: firstOpponent,                                                                       // 35
      secondOpponent: secondOpponent,                                                                     // 36
      game: game,                                                                                         // 37
      event: event,                                                                                       // 38
      startAt: startAt,                                                                                   // 39
      createdAt: new Date(),                                                                              // 40
      winner: winner,                                                                                     // 41
      complete: complete,                                                                                 // 42
      canceled: canceled                                                                                  // 43
    });                                                                                                   // 34
  },                                                                                                      // 45
  'matches.remove': function (id) {                                                                       // 46
    Matches.remove(id);                                                                                   // 47
  },                                                                                                      // 48
  'matches.setWinner': function (id, winner) {                                                            // 49
    Matches.update({                                                                                      // 50
      _id: id                                                                                             // 50
    }, {                                                                                                  // 50
      $set: {                                                                                             // 50
        winner: winner,                                                                                   // 50
        complete: true                                                                                    // 50
      }                                                                                                   // 50
    });                                                                                                   // 50
  } //   "teams.setChecked"(taskId, setChecked) {                                                         // 51
  //     check(taskId, String);                                                                           // 53
  //     check(setChecked, Boolean);                                                                      // 54
  //     Teams.update(taskId, { $set: { checked: setChecked } });                                         // 56
  //   }                                                                                                  // 57
                                                                                                          //
});                                                                                                       // 18
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"teams.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/teams.js                                                                                   //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
module.export({                                                                                           // 1
  Teams: function () {                                                                                    // 1
    return Teams;                                                                                         // 1
  }                                                                                                       // 1
});                                                                                                       // 1
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
var Teams = new Mongo.Collection('teams');                                                                // 5
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 7
  // This code only runs on the server                                                                    // 8
  Meteor.publish('teams', function () {                                                                   // 9
    function TeamsPublication() {                                                                         // 9
      return Teams.find();                                                                                // 10
    }                                                                                                     // 11
                                                                                                          //
    return TeamsPublication;                                                                              // 9
  }());                                                                                                   // 9
}                                                                                                         // 12
                                                                                                          //
Meteor.methods({                                                                                          // 14
  'teams.insert': function (name, logo) {                                                                 // 15
    check(name, String); // Make sure the user is logged in before inserting a task                       // 16
                                                                                                          //
    if (!Meteor.userId()) {                                                                               // 19
      throw new Meteor.Error('not-authorized');                                                           // 20
    }                                                                                                     // 21
                                                                                                          //
    Teams.insert({                                                                                        // 23
      name: name,                                                                                         // 24
      logo: logo,                                                                                         // 25
      createdAt: new Date()                                                                               // 26
    });                                                                                                   // 23
  },                                                                                                      // 28
  'teams.getname': function (id) {                                                                        // 29
    return Teams.findOne({                                                                                // 30
      _id: id                                                                                             // 31
    });                                                                                                   // 30
  },                                                                                                      // 33
  'teams.remove': function (id) {                                                                         // 34
    check(id, String);                                                                                    // 35
    Teams.remove(id);                                                                                     // 36
  },                                                                                                      // 37
  'teams.update': function (id, name, logo) {                                                             // 38
    check(id, String);                                                                                    // 39
    Teams.update({                                                                                        // 40
      _id: id                                                                                             // 40
    }, {                                                                                                  // 40
      name: name,                                                                                         // 40
      logo: logo                                                                                          // 40
    });                                                                                                   // 40
  }                                                                                                       // 41
});                                                                                                       // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// imports/api/users.js                                                                                   //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
var Mongo = void 0;                                                                                       // 1
module.watch(require("meteor/mongo"), {                                                                   // 1
  Mongo: function (v) {                                                                                   // 1
    Mongo = v;                                                                                            // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 1);                                                                                                    // 1
var check = void 0;                                                                                       // 1
module.watch(require("meteor/check"), {                                                                   // 1
  check: function (v) {                                                                                   // 1
    check = v;                                                                                            // 1
  }                                                                                                       // 1
}, 2);                                                                                                    // 1
                                                                                                          //
if (Meteor.isServer) {                                                                                    // 5
  Meteor.publish('users.name', function () {                                                              // 6
    return Meteor.users.find({}, {                                                                        // 7
      fields: {                                                                                           // 7
        _id: 1,                                                                                           // 7
        username: 1                                                                                       // 7
      }                                                                                                   // 7
    });                                                                                                   // 7
  });                                                                                                     // 8
}                                                                                                         // 9
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"uploadImage.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/uploadImage.js                                                                                  //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
                                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// server/main.js                                                                                         //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
var Meteor = void 0;                                                                                      // 1
module.watch(require("meteor/meteor"), {                                                                  // 1
  Meteor: function (v) {                                                                                  // 1
    Meteor = v;                                                                                           // 1
  }                                                                                                       // 1
}, 0);                                                                                                    // 1
module.watch(require("../imports/api/users.js"));                                                         // 1
module.watch(require("../imports/api/teams.js"));                                                         // 1
module.watch(require("../imports/api/matches.js"));                                                       // 1
module.watch(require("../imports/api/games.js"));                                                         // 1
module.watch(require("../imports/api/events.js"));                                                        // 1
module.watch(require("../imports/api/bets.js"));                                                          // 1
module.watch(require("../imports/api/images.js"));                                                        // 1
Meteor.startup(function () {// code to run on server at startup                                           // 10
});                                                                                                       // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("./server/uploadImage.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
